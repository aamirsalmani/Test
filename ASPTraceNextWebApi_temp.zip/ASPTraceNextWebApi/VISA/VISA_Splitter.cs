﻿using ImportData;
using System;
using System.Data;
using System.Globalization;
using System.IO;
using System.Reflection;
using System.Text;
using System.Text.RegularExpressions;
using Utility;

namespace VISA
{
    public class VISA_Splitter
    { 
        private readonly string _connectionString;
        BulkImports bulkimports;
        public VISA_Splitter(string connectionString, string MekKey1, string MekKey2)
        {
            _connectionString = connectionString; 
            AesEncryption.EMEK1 = MekKey1;
            AesEncryption.EMEK2 = MekKey2;
            bulkimports = new BulkImports(_connectionString, MekKey1, MekKey2);
        }

        string GetUniqueID()
        {
            Random rnd = new Random();
            int value = rnd.Next(1000, 9999);
            string UniqueID = DateTime.Now.ToString("ddMMyyyyHHmmssfff") + value.ToString();
            return UniqueID;

        }

        static string RemoveDigits(string key)
        {
            return Regex.Replace(key, @"\d", "");
        }

        public DataSet SplitDataISSUER(string path, string FileName, DataSet dt, out int InsertCount, out int TotalCount, string UserName, string ClientID)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DataSet _DataSet = new DataSet();
            int month = 0;
            int fyear = 0;
            string FileNameSplit = string.Empty;
            string FileDateString = string.Empty;
            int FFyear = 0;
            var FileDate = new DateTime();
            FFyear = 2022;
            fyear = FFyear;

            //if (FileName.Substring(0, 3) == "CTF")
            //    {

            //    FileNameSplit = FileName.Substring(8, 5);
            //    FDate = Convert.ToInt32(FileNameSplit);
            //    Fday = FDate % 1000;
            //    if (Fday == 366)
            //        {
            //        Fday = Fday - 1;
            //        }
            //   FFyear = int.Parse("20" + FileNameSplit.Substring(0, 2));


            //    var Fdate = new DateTime(FFyear, 1, 1);
            //    FileDate = Fdate.AddDays(Fday - 1);
            //    FileDateString = FileDate.ToString();
            //    month = FileDate.Month;//month = int.Parse(FileDateString.Substring(5, 2));
            //    fyear = FFyear;

            //    }
            //else
            //    {

            //    if (FileName.Length > 14)
            //        {
            //        InsertCount = 0;
            //        TotalCount = 0;
            //        return _DataSet;
            //        }

            //    month = int.Parse(FileName.Substring(3, 2));
            //    fyear = int.Parse(FileName.Substring(6, 4));


            //    string FileName1 = FileName.Substring(0, 2) + "/" + FileName.Substring(3, 2) + "/" + FileName.Substring(6, 4) + " 00:00:00";
            //    FileDate = DateTime.ParseExact(FileName1, "dd/MM/yyyy HH:mm:ss", null);

            //    }

            FileDate = DateTime.Now;
            InsertCount = 0;
            TotalCount = 0;
            int LineNo = 0;



            DataSet ds = new DataSet();

            DataTable _DataTable0 = new DataTable();
            _DataTable0.Columns.Add("ClientID", typeof(int));
            _DataTable0.Columns.Add("UniqueID", typeof(string));
            _DataTable0.Columns.Add("TxnsCode", typeof(string));
            _DataTable0.Columns.Add("TxnsCodeQ", typeof(string));
            _DataTable0.Columns.Add("TxnsCSN", typeof(string));
            _DataTable0.Columns.Add("CardNumber", typeof(string));
            _DataTable0.Columns.Add("CardNumberExt", typeof(string));
            _DataTable0.Columns.Add("FloorLimit", typeof(string));
            _DataTable0.Columns.Add("ExceptionFile", typeof(string));
            _DataTable0.Columns.Add("PCAS", typeof(string));
            _DataTable0.Columns.Add("AcqReferenceNumber", typeof(string));
            _DataTable0.Columns.Add("AcqBusinessID", typeof(string));
            _DataTable0.Columns.Add("PurchaseDate", typeof(DateTime));
            _DataTable0.Columns.Add("DestAmount", typeof(decimal));
            _DataTable0.Columns.Add("DestCCY", typeof(string));
            _DataTable0.Columns.Add("SrcAmount", typeof(decimal));
            _DataTable0.Columns.Add("SrcCCY", typeof(string));
            _DataTable0.Columns.Add("MarchantName", typeof(string));
            _DataTable0.Columns.Add("MarchantCity", typeof(string));
            _DataTable0.Columns.Add("MarchantCountryCode", typeof(string));
            _DataTable0.Columns.Add("MarchantCateCode", typeof(string));
            _DataTable0.Columns.Add("MarchantZIPCode", typeof(string));
            _DataTable0.Columns.Add("MarchantSPCode", typeof(string));
            _DataTable0.Columns.Add("ReqPaymentService", typeof(string));
            _DataTable0.Columns.Add("NoOfPaymentForm", typeof(string));
            _DataTable0.Columns.Add("UsageCode", typeof(string));
            _DataTable0.Columns.Add("ReasonCode", typeof(string));
            _DataTable0.Columns.Add("SettlementFlag", typeof(string));
            _DataTable0.Columns.Add("AuthCharIndicator", typeof(string));
            _DataTable0.Columns.Add("AuthCode", typeof(string));
            _DataTable0.Columns.Add("POSTerminalCapability", typeof(string));
            _DataTable0.Columns.Add("Reserved1", typeof(string));
            _DataTable0.Columns.Add("CardHolderID", typeof(string));
            _DataTable0.Columns.Add("CollectionOnlyFlag", typeof(string));
            _DataTable0.Columns.Add("POSEntryMode", typeof(string));
            _DataTable0.Columns.Add("CentralProcessDate", typeof(DateTime));
            _DataTable0.Columns.Add("ReimbursementAttribute", typeof(string));
            _DataTable0.Columns.Add("ReserveField1", typeof(string));
            _DataTable0.Columns.Add("ReserveField2", typeof(string));
            _DataTable0.Columns.Add("ReserveField3", typeof(string));
            _DataTable0.Columns.Add("ReserveField4", typeof(string));
            _DataTable0.Columns.Add("ReserveField5", typeof(string));
            _DataTable0.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable0.Columns.Add("NoOfDuplicate", typeof(string));
            _DataTable0.Columns.Add("FileName", typeof(string));
            _DataTable0.Columns.Add("FilePath", typeof(string));
            _DataTable0.Columns.Add("FileDate", typeof(DateTime));
            _DataTable0.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable0.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable0.Columns.Add("CreatedBy", typeof(string));
            _DataTable0.Columns.Add("ModifiedBy", typeof(string));
            _DataTable0.Columns.Add("ECardNumber", typeof(string));
            _DataTable0.Columns.Add("IssuingNetwork", typeof(string));
            _DataTable0.Columns.Add("CardScheme", typeof(string));

            DataTable _DataTable1 = new DataTable();
            _DataTable1.Columns.Add("ClientID", typeof(int));
            _DataTable1.Columns.Add("UniqueID", typeof(string));
            _DataTable1.Columns.Add("BusinessFC", typeof(string));
            _DataTable1.Columns.Add("TokanAssuranceLevel", typeof(string));
            _DataTable1.Columns.Add("Reserved2", typeof(string));
            _DataTable1.Columns.Add("ChargebackRefNo", typeof(string));
            _DataTable1.Columns.Add("DocIndicator", typeof(string));
            _DataTable1.Columns.Add("MemMsgText", typeof(string));
            _DataTable1.Columns.Add("SpecialCondition", typeof(string));
            _DataTable1.Columns.Add("FeeProgram", typeof(string));
            _DataTable1.Columns.Add("IssuerCharge", typeof(string));
            _DataTable1.Columns.Add("Reserved3", typeof(string));
            _DataTable1.Columns.Add("CardAcceptorID", typeof(string));
            _DataTable1.Columns.Add("TerminalID", typeof(string));
            _DataTable1.Columns.Add("NationalRBFee", typeof(string));
            _DataTable1.Columns.Add("MPECIndicator", typeof(string));
            _DataTable1.Columns.Add("SpecialChargeback", typeof(string));
            _DataTable1.Columns.Add("IntTraceNumber", typeof(string));
            _DataTable1.Columns.Add("AcceptTerminal", typeof(string));
            _DataTable1.Columns.Add("PrepaidCard", typeof(string));
            _DataTable1.Columns.Add("ServiceDevlopmentField", typeof(string));
            _DataTable1.Columns.Add("AVSResponseCode", typeof(string));
            _DataTable1.Columns.Add("AuthSourceCode", typeof(string));
            _DataTable1.Columns.Add("PurchaseIdenFormat", typeof(string));
            _DataTable1.Columns.Add("AccountSelection", typeof(string));
            _DataTable1.Columns.Add("InstallmentPayCount", typeof(string));
            _DataTable1.Columns.Add("PurchaseIdentifier", typeof(string));
            _DataTable1.Columns.Add("CashBack", typeof(string));
            _DataTable1.Columns.Add("ChipConCode", typeof(string));
            _DataTable1.Columns.Add("POSEnviroment", typeof(string));
            _DataTable1.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable1.Columns.Add("NoOfDuplicate", typeof(string));

            DataTable _DataTable3 = new DataTable();
            _DataTable3.Columns.Add("ClientID", typeof(int));
            _DataTable3.Columns.Add("UniqueID", typeof(string));
            _DataTable3.Columns.Add("Reserved5", typeof(string));
            _DataTable3.Columns.Add("BusinessFCLG", typeof(string));
            _DataTable3.Columns.Add("Reserved6", typeof(string));
            _DataTable3.Columns.Add("LodgingNo", typeof(string));
            _DataTable3.Columns.Add("LodExtraCharge", typeof(string));
            _DataTable3.Columns.Add("Reserved7", typeof(string));
            _DataTable3.Columns.Add("LodgingDate", typeof(string));
            _DataTable3.Columns.Add("DailyRoomRate", typeof(string));
            _DataTable3.Columns.Add("TotalTax", typeof(string));
            _DataTable3.Columns.Add("PrepaidExpns", typeof(string));
            _DataTable3.Columns.Add("FoodCharges", typeof(string));
            _DataTable3.Columns.Add("FolioCashAdv", typeof(string));
            _DataTable3.Columns.Add("RoomNight", typeof(string));
            _DataTable3.Columns.Add("TotalRoomTax", typeof(string));
            _DataTable3.Columns.Add("Reserved8", typeof(string));
            _DataTable3.Columns.Add("Reserved9", typeof(string));
            _DataTable3.Columns.Add("FastFundsIn", typeof(string));
            _DataTable3.Columns.Add("BusinessFCCR", typeof(string));
            _DataTable3.Columns.Add("BusinessAppID", typeof(string));
            _DataTable3.Columns.Add("SourceOfFunds", typeof(string));
            _DataTable3.Columns.Add("PaymentRevRC", typeof(string));
            _DataTable3.Columns.Add("SenderRefNo", typeof(string));
            _DataTable3.Columns.Add("SenderAcNo", typeof(string));
            _DataTable3.Columns.Add("SenderName", typeof(string));
            _DataTable3.Columns.Add("SenderAdd", typeof(string));
            _DataTable3.Columns.Add("SenderCity", typeof(string));
            _DataTable3.Columns.Add("SenderState", typeof(string));
            _DataTable3.Columns.Add("SenderCountry", typeof(string));
            _DataTable3.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable3.Columns.Add("NoOfDuplicate", typeof(string));


            DataTable _DataTable4 = new DataTable();
            _DataTable4.Columns.Add("ClientID", typeof(int));
            _DataTable4.Columns.Add("UniqueID", typeof(string));
            _DataTable4.Columns.Add("AUniqueID", typeof(string));
            _DataTable4.Columns.Add("Reserved10", typeof(string));
            _DataTable4.Columns.Add("BusinessFC4", typeof(string));
            _DataTable4.Columns.Add("NetIdCode", typeof(string));
            _DataTable4.Columns.Add("ConforInfo", typeof(string));
            _DataTable4.Columns.Add("AdjProceIn", typeof(string));
            _DataTable4.Columns.Add("MsgReasonCode", typeof(string));
            _DataTable4.Columns.Add("SurchargeAmnt", typeof(string));
            _DataTable4.Columns.Add("SurCrDr", typeof(string));
            _DataTable4.Columns.Add("VisaIUO", typeof(string));
            _DataTable4.Columns.Add("Reserved11", typeof(string));
            _DataTable4.Columns.Add("SurAmntBillCCY", typeof(string));
            _DataTable4.Columns.Add("MoneyTrfExchFee", typeof(string));
            _DataTable4.Columns.Add("Reserved12", typeof(string));
            _DataTable4.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable4.Columns.Add("NoOfDuplicate", typeof(string));



            DataTable _DataTable5 = new DataTable();
            _DataTable5.Columns.Add("ClientID", typeof(int));
            _DataTable5.Columns.Add("UniqueID", typeof(string));
            _DataTable5.Columns.Add("TxnsIdentifier", typeof(string));
            _DataTable5.Columns.Add("AuthAmount", typeof(decimal));
            _DataTable5.Columns.Add("AuthCCY", typeof(string));
            _DataTable5.Columns.Add("AuthResponseCode", typeof(string));
            _DataTable5.Columns.Add("ValidationCode", typeof(string));
            _DataTable5.Columns.Add("ExcludedTxnsIdenReason", typeof(string));
            _DataTable5.Columns.Add("CRSProcessCode", typeof(string));
            _DataTable5.Columns.Add("ChargeRight", typeof(string));
            _DataTable5.Columns.Add("MultiClearingSN", typeof(string));
            _DataTable5.Columns.Add("MultiClearingSC", typeof(string));
            _DataTable5.Columns.Add("MarketSADI", typeof(string));
            _DataTable5.Columns.Add("TotalAuthAmount", typeof(decimal));
            _DataTable5.Columns.Add("InformationIndicator", typeof(string));
            _DataTable5.Columns.Add("MarchantTelephoneNumber", typeof(string));
            _DataTable5.Columns.Add("AdditionalData", typeof(string));
            _DataTable5.Columns.Add("MerchantVolume", typeof(string));
            _DataTable5.Columns.Add("ElectronicsCGI", typeof(string));
            _DataTable5.Columns.Add("MerchantVerValue", typeof(string));
            _DataTable5.Columns.Add("InterchangeFeeAmount", typeof(decimal));
            _DataTable5.Columns.Add("InterchangeFeeSign", typeof(string));
            _DataTable5.Columns.Add("SCBCCYExchangeRate", typeof(decimal));
            _DataTable5.Columns.Add("BCDCCYExhangeRate", typeof(decimal));
            _DataTable5.Columns.Add("ISAAmount", typeof(decimal));
            _DataTable5.Columns.Add("ProductID", typeof(string));
            _DataTable5.Columns.Add("ProgramID", typeof(string));
            _DataTable5.Columns.Add("DCCIndicator", typeof(string));
            _DataTable5.Columns.Add("AccountTypeIdentification", typeof(string));
            _DataTable5.Columns.Add("SpendQIndicator", typeof(string));
            _DataTable5.Columns.Add("PanToken", typeof(string));
            _DataTable5.Columns.Add("Reserved4", typeof(string));
            _DataTable5.Columns.Add("CVV2ResultCode", typeof(string));
            _DataTable5.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable5.Columns.Add("NoOfDuplicate", typeof(string));


            DataTable _DataTable6 = new DataTable();
            _DataTable6.Columns.Add("ClientID", typeof(int));
            _DataTable6.Columns.Add("UniqueID", typeof(string));
            _DataTable6.Columns.Add("LocalTax", typeof(string));
            _DataTable6.Columns.Add("LocalTaxIn", typeof(string));
            _DataTable6.Columns.Add("NtlTax", typeof(string));
            _DataTable6.Columns.Add("NtlTaxIn", typeof(string));
            _DataTable6.Columns.Add("BusinessRefNo", typeof(string));
            _DataTable6.Columns.Add("CustVATRegNo", typeof(string));
            _DataTable6.Columns.Add("Reserved13", typeof(string));
            _DataTable6.Columns.Add("SummaryCommCode", typeof(string));
            _DataTable6.Columns.Add("OtherTax", typeof(string));
            _DataTable6.Columns.Add("MsgID", typeof(string));
            _DataTable6.Columns.Add("TimeOfPurchase", typeof(string));
            _DataTable6.Columns.Add("CustCode", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode1", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode2", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode3", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode4", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode5", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode6", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode7", typeof(string));
            _DataTable6.Columns.Add("NonFuelProdCode8", typeof(string));
            _DataTable6.Columns.Add("MerPostCode", typeof(string));
            _DataTable6.Columns.Add("Reserved14", typeof(string));
            _DataTable6.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable6.Columns.Add("NoOfDuplicate", typeof(string));

            DataTable _DataTable7 = new DataTable();
            _DataTable7.Columns.Add("ClientID", typeof(int));
            _DataTable7.Columns.Add("UniqueID", typeof(string));
            _DataTable7.Columns.Add("TxnsType", typeof(string));
            _DataTable7.Columns.Add("CardSeqNo", typeof(string));
            _DataTable7.Columns.Add("TerminalTxnsDate", typeof(string));
            _DataTable7.Columns.Add("TerminalCapProfile", typeof(string));
            _DataTable7.Columns.Add("TerminalCountryCode", typeof(string));
            _DataTable7.Columns.Add("TerminalSerialNo", typeof(string));
            _DataTable7.Columns.Add("UnpredictableNo", typeof(string));
            _DataTable7.Columns.Add("AppTxnsCounter", typeof(string));
            _DataTable7.Columns.Add("AppIntProfile", typeof(string));
            _DataTable7.Columns.Add("Cryptogram", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData2", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData3", typeof(string));
            _DataTable7.Columns.Add("TerminalVerResult", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData47", typeof(string));
            _DataTable7.Columns.Add("CryptogramAmount", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData8", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData916", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData1", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData17", typeof(string));
            _DataTable7.Columns.Add("IssuerAppData1832", typeof(string));
            _DataTable7.Columns.Add("FormFactInd", typeof(string));
            _DataTable7.Columns.Add("IssuerScriptResults", typeof(string));
            _DataTable7.Columns.Add("RevEntryLeg", typeof(string));
            _DataTable7.Columns.Add("NoOfDuplicate", typeof(string));

            #region _DataTable1020
            DataTable _DataTable1020 = new DataTable();
            _DataTable1020.Columns.Add("ClientID", typeof(int));
            _DataTable1020.Columns.Add("Transaction_Code", typeof(string));
            _DataTable1020.Columns.Add("Transaction_Code_Qualifier", typeof(string));
            _DataTable1020.Columns.Add("Transaction_Component_Sequence_Number", typeof(string));
            _DataTable1020.Columns.Add("Destination_BIN", typeof(string));
            _DataTable1020.Columns.Add("Source_BIN", typeof(string));
            _DataTable1020.Columns.Add("Reason_Code", typeof(string));
            _DataTable1020.Columns.Add("Country_Code", typeof(string));
            _DataTable1020.Columns.Add("Event_Date", typeof(DateTime));
            _DataTable1020.Columns.Add("Account_Number", typeof(string));
            _DataTable1020.Columns.Add("Account_Number_Extension", typeof(string));
            _DataTable1020.Columns.Add("Destination_Amount", typeof(decimal));
            _DataTable1020.Columns.Add("Destination_Currency_Code", typeof(string));
            _DataTable1020.Columns.Add("Source_Amount", typeof(decimal));
            _DataTable1020.Columns.Add("Source_Currency_Code", typeof(string));
            _DataTable1020.Columns.Add("Message_Text", typeof(string));
            _DataTable1020.Columns.Add("Settlement_Flag", typeof(string));
            _DataTable1020.Columns.Add("Transaction_Identifier", typeof(string));
            _DataTable1020.Columns.Add("Reserved", typeof(string));
            _DataTable1020.Columns.Add("Central_Processing_Date", typeof(string));
            _DataTable1020.Columns.Add("Reimbursement_Attribute", typeof(string));
            _DataTable1020.Columns.Add("CreatedOn", typeof(DateTime));
            _DataTable1020.Columns.Add("CreatedBy", typeof(string));
            _DataTable1020.Columns.Add("ModifiedOn", typeof(DateTime));
            _DataTable1020.Columns.Add("ModifiedBy", typeof(string));
            _DataTable1020.Columns.Add("VisaFileDate", typeof(DateTime));
            #endregion _DataTable1020

            ds = dt;
            //string LogType = dt.Rows[0]["FileName"].ToString();
            //string xmlFile = dt.Rows[0]["FormatDescriptionXml"].ToString();
            string RevEntryLeg = "1";
            //ds.ReadXml(new XmlTextReader(new StringReader(xmlFile)));
            //int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
            // ds.ReadXml(VisaFormatPath);

            string year = string.Empty;
            string Transaction_Code = string.Empty;
            string Transaction_Code_Qualifier = string.Empty;
            string Transaction_Component_Sequence_Number = string.Empty;
            string Destination_BIN = string.Empty;
            string Source_BIN = string.Empty;
            string Reason_Code = string.Empty;
            string Country_Code = string.Empty;
            string Event_Date = string.Empty;
            string Account_Number = string.Empty;
            string Account_Number_Extension = string.Empty;
            decimal Destination_Amount = 0;
            string Destination_Currency_Code = string.Empty;
            decimal Source_Amount = 0;
            string Source_Currency_Code = string.Empty;
            string Message_Text = string.Empty;
            string Settlement_Flag = string.Empty;
            string Transaction_Identifier = string.Empty;
            string Reserved = string.Empty;
            string Central_Processing_Date = string.Empty;
            string Reimbursement_Attribute = string.Empty;

            string UniqueID = string.Empty;
            int Incr = 1;
            string TxnsCode = string.Empty;
            string TxnsCodeQ = string.Empty;
            string TxnsCSN = string.Empty;
            string AccountNumber = string.Empty;
            string AccountNumberExt = string.Empty;
            string FloorLimit = string.Empty;
            string ExceptionFile = string.Empty;
            string PCAS = string.Empty;
            string AcqReferenceNumber = string.Empty;
            string AcqBusinessID = string.Empty;
            string PurchaseDate = string.Empty;
            string DestAmount = string.Empty;
            string DestCCY = string.Empty;
            string SrcAmount = string.Empty;
            string SrcCCY = string.Empty;
            string MarchantName = string.Empty;
            string MarchantCity = string.Empty;
            string MarchantCountryCode = string.Empty;
            string MarchantCateCode = string.Empty;
            string MarchantZIPCode = string.Empty;
            string MarchantSPCode = string.Empty;
            string ReqPaymentService = string.Empty;
            string NoOfPaymentForm = string.Empty;
            string UsageCode = string.Empty;
            string ReasonCode = string.Empty;
            string SettlementFlag = string.Empty;
            string AuthCharIndicator = string.Empty;
            string AuthCode = string.Empty;
            string POSTerminalCapability = string.Empty;
            string Reserved1 = string.Empty;
            string CardHolderID = string.Empty;
            string CollectionOnlyFlag = string.Empty;
            string POSEntryMode = string.Empty;
            string CentralProcessDate = string.Empty;
            string ReimbursementAttribute = string.Empty;
            string BusinessFC = string.Empty;
            string TokanAssuranceLevel = string.Empty;
            string Reserved2 = string.Empty;
            string ChargebackRefNo = string.Empty;
            string DocIndicator = string.Empty;
            string MemMsgText = string.Empty;
            string SpecialCondition = string.Empty;
            string FeeProgram = string.Empty;
            string IssuerCharge = string.Empty;
            string Reserved3 = string.Empty;
            string CardAcceptorID = string.Empty;
            string TerminalID = string.Empty;
            string NationalRBFee = string.Empty;
            string MPECIndicator = string.Empty;
            string SpecialChargeback = string.Empty;
            string IntTraceNumber = string.Empty;
            string AcceptTerminal = string.Empty;
            string PrepaidCard = string.Empty;
            string ServiceDevlopmentField = string.Empty;
            string AVSResponseCode = string.Empty;
            string AuthSourceCode = string.Empty;
            string PurchaseIdenFormat = string.Empty;
            string AccountSelection = string.Empty;
            string InstallmentPayCount = string.Empty;
            string PurchaseIdentifier = string.Empty;
            string CashBack = string.Empty;
            string ChipConCode = string.Empty;
            string POSEnviroment = string.Empty;
            string TxnsIdentifier = string.Empty;
            string AuthAmount = string.Empty;
            string AuthCCY = string.Empty;
            string AuthResponseCode = string.Empty;
            string ValidationCode = string.Empty;
            string ExcludedTxnsIdenReason = string.Empty;
            string CRSProcessCode = string.Empty;
            string ChargeRight = string.Empty;
            string MultiClearingSN = string.Empty;
            string MultiClearingSC = string.Empty;
            string MarketSADI = string.Empty;
            string TotalAuthAmount = string.Empty;
            string InformationIndicator = string.Empty;
            string MarchantTelephoneNumber = string.Empty;
            string AdditionalData = string.Empty;
            string MerchantVolume = string.Empty;
            string ElectronicsCGI = string.Empty;
            string MerchantVerValue = string.Empty;
            string InterchangeFeeAmount = string.Empty;
            string InterchangeFeeSign = string.Empty;
            string SCBCCYExchangeRate = string.Empty;
            string BCDCCYExhangeRate = string.Empty;
            string ISAAmount = string.Empty;
            string ProductID = string.Empty;
            string ProgramID = string.Empty;
            string DCCIndicator = string.Empty;
            string AccountTypeIdentification = string.Empty;
            string SpendQIndicator = string.Empty;
            string PanToken = string.Empty;
            string Reserved4 = string.Empty;
            string CVV2ResultCode = string.Empty;
            string ReserveField1 = string.Empty;
            string ReserveField2 = string.Empty;
            string ReserveField3 = string.Empty;
            string ReserveField4 = string.Empty;
            string ReserveField5 = string.Empty;
            string Reserved5 = string.Empty;
            string BusinessFCLG = string.Empty;
            string Reserved6 = string.Empty;
            string LodgingNo = string.Empty;
            string LodExtraCharge = string.Empty;
            string Reserved7 = string.Empty;
            string LodgingDate = string.Empty;
            string DailyRoomRate = string.Empty;
            string TotalTax = string.Empty;
            string PrepaidExpns = string.Empty;
            string FoodCharges = string.Empty;
            string FolioCashAdv = string.Empty;
            string RoomNight = string.Empty;
            string TotalRoomTax = string.Empty;
            string Reserved8 = string.Empty;
            string Reserved9 = string.Empty;
            string FastFundsIn = string.Empty;
            string BusinessFCCR = string.Empty;
            string BusinessAppID = string.Empty;
            string SourceOfFunds = string.Empty;
            string PaymentRevRC = string.Empty;
            string SenderRefNo = string.Empty;
            string SenderAcNo = string.Empty;
            string SenderName = string.Empty;
            string SenderAdd = string.Empty;
            string SenderCity = string.Empty;
            string SenderState = string.Empty;
            string SenderCountry = string.Empty;
            string AUniqueID = string.Empty;
            string Reserved10 = string.Empty;
            string BusinessFC4 = string.Empty;
            string NetIdCode = string.Empty;
            string ConforInfo = string.Empty;
            string AdjProceIn = string.Empty;
            string MsgReasonCode = string.Empty;
            string SurchargeAmnt = string.Empty;
            string SurCrDr = string.Empty;
            string VisaIUO = string.Empty;
            string Reserved11 = string.Empty;
            string SurAmntBillCCY = string.Empty;
            string MoneyTrfExchFee = string.Empty;
            string Reserved12 = string.Empty;
            string LocalTax = string.Empty;
            string LocalTaxIn = string.Empty;
            string NtlTax = string.Empty;
            string NtlTaxIn = string.Empty;
            string BusinessRefNo = string.Empty;
            string CustVATRegNo = string.Empty;
            string Reserved13 = string.Empty;
            string SummaryCommCode = string.Empty;
            string OtherTax = string.Empty;
            string MsgID = string.Empty;
            string TimeOfPurchase = string.Empty;
            string CustCode = string.Empty;
            string NonFuelProdCode1 = string.Empty;
            string NonFuelProdCode2 = string.Empty;
            string NonFuelProdCode3 = string.Empty;
            string NonFuelProdCode4 = string.Empty;
            string NonFuelProdCode5 = string.Empty;
            string NonFuelProdCode6 = string.Empty;
            string NonFuelProdCode7 = string.Empty;
            string NonFuelProdCode8 = string.Empty;
            string MerPostCode = string.Empty;
            string Reserved14 = string.Empty;
            string TxnsType = string.Empty;
            string CardSeqNo = string.Empty;
            string TerminalTxnsDate = string.Empty;
            string TerminalCapProfile = string.Empty;
            string TerminalCountryCode = string.Empty;
            string TerminalSerialNo = string.Empty;
            string UnpredictableNo = string.Empty;
            string AppTxnsCounter = string.Empty;
            string AppIntProfile = string.Empty;
            string Cryptogram = string.Empty;
            string IssuerAppData2 = string.Empty;
            string IssuerAppData3 = string.Empty;
            string TerminalVerResult = string.Empty;
            string IssuerAppData47 = string.Empty;
            string CryptogramAmount = string.Empty;
            string IssuerAppData8 = string.Empty;
            string IssuerAppData916 = string.Empty;
            string IssuerAppData1 = string.Empty;
            string IssuerAppData17 = string.Empty;
            string IssuerAppData1832 = string.Empty;
            string FormFactInd = string.Empty;
            string IssuerScriptResults = string.Empty;


            string TCR = string.Empty;
            bool TxnsNo = false;

            string year1 = string.Empty;

            string CardNumber = string.Empty;
            string CardType = string.Empty;
            string ECardNumber = string.Empty;

            DateTime? TerminalTxnsDateTime;
            DateTime? LodgingDateTime;
            DateTime TransactionDateTime;
            DateTime tempDate;
            DateTime CPDate;
            int Start = 0;
            int End = 0;

            string line1 = string.Empty;

            string CardScheme = "VISA";
            string IssuingNetwork = "VISA";

            try
            {
                

                
                
                
                

                string[] TotalCountArray = File.ReadAllLines(path);
                TotalCount = TotalCountArray.Length;


                for (int line = 0; line < TotalCount; line++)
                {
                    line1 = Regex.Replace(TotalCountArray[line].ToString(), "[^ -~]+", string.Empty);


                    #region 10_20FeeCollectionData
                    if (line1.Substring(0, 4).Contains("2000") || line1.Substring(0, 4).Contains("1000"))
                    {

                        year = string.Empty;
                        Transaction_Code = string.Empty;
                        Transaction_Code_Qualifier = string.Empty;
                        Transaction_Component_Sequence_Number = string.Empty;
                        Destination_BIN = string.Empty;
                        Source_BIN = string.Empty;
                        Reason_Code = string.Empty;
                        Country_Code = string.Empty;
                        Event_Date = string.Empty;
                        Account_Number = string.Empty;
                        Account_Number_Extension = string.Empty;
                        Destination_Amount = 0;
                        Destination_Currency_Code = string.Empty;
                        Source_Amount = 0;
                        Source_Currency_Code = string.Empty;
                        Message_Text = string.Empty;
                        Settlement_Flag = string.Empty;
                        Transaction_Identifier = string.Empty;
                        Reserved = string.Empty;
                        Central_Processing_Date = string.Empty;
                        Reimbursement_Attribute = string.Empty;

                        year1 = line1.Substring(33, 1).ToString();

                        Transaction_Code = line1.Substring(0, 2);
                        Transaction_Code_Qualifier = line1.Substring(2, 1);
                        Transaction_Component_Sequence_Number = line1.Substring(3, 1);
                        Destination_BIN = line1.Substring(4, 6);
                        Source_BIN = line1.Substring(10, 6);
                        Reason_Code = line1.Substring(16, 4);
                        Country_Code = line1.Substring(20, 3);
                        Event_Date = line1.Substring(23, 4);
                        if (Convert.ToInt32(Event_Date.Substring(0, 2)) > month)
                        {
                            year1 = (fyear - 1).ToString();
                        }
                        else
                        {
                            year1 = fyear.ToString();//DateTime.Now.Year.ToString();
                        }
                        Event_Date = Event_Date.Substring(2, 2) + "/" + Event_Date.Substring(0, 2) + "/" + year1 + " 00:00:00";

                        tempDate = DateTime.ParseExact(Event_Date, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                        Account_Number = line1.Substring(27, 16);
                        Account_Number_Extension = line1.Substring(43, 3);
                        Destination_Amount = Convert.ToDecimal(line1.Substring(46, 10) + "." + line1.Substring(56, 02));
                        Destination_Currency_Code = line1.Substring(58, 3);
                        Source_Amount = Convert.ToDecimal(line1.Substring(61, 10) + "." + line1.Substring(71, 02));
                        Source_Currency_Code = line1.Substring(73, 3);
                        Message_Text = line1.Substring(76, 70);
                        Settlement_Flag = line1.Substring(146, 1);
                        Transaction_Identifier = line1.Substring(147, 15);
                        Reserved = line1.Substring(162, 1);
                        Central_Processing_Date = line1.Substring(163, 4);
                        //if (Convert.ToInt32(Central_Processing_Date.Substring(0, 2)) > month)
                        //    {
                        //    year = (fyear - 1).ToString();
                        //    }
                        //else
                        //    {
                        year = fyear.ToString();//DateTime.Now.Year.ToString();
                                                // }
                        Central_Processing_Date = Central_Processing_Date.Substring(2, 2) + "/" + Central_Processing_Date.Substring(0, 2) + "/" + year + " 00:00:00";
                        CPDate = DateTime.ParseExact(Event_Date, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                        Reimbursement_Attribute = line1.Substring(167, 1);


                        _DataTable1020.Rows.Add(Transaction_Code.Trim(), Transaction_Code_Qualifier, Transaction_Component_Sequence_Number.Trim(),
                        Destination_BIN.Trim(), Source_BIN, Reason_Code, Country_Code, tempDate, Account_Number.Trim(), Account_Number_Extension,
                        Destination_Amount, Destination_Currency_Code, Source_Amount, Source_Currency_Code, Message_Text, Settlement_Flag,
                        Transaction_Identifier.Trim(), Reserved, CPDate, Reimbursement_Attribute, System.DateTime.Now, UserName, System.DateTime.Now, UserName, FileDate);

                    }
                    #endregion 10_20FeeCollectionData




                    if (line1.StartsWith("0500") || line1.StartsWith("0600") || line1.StartsWith("0700") || line1.StartsWith("2500") || line1.StartsWith("2600") || line1.StartsWith("2700")
                         || line1.StartsWith("1500") || line1.StartsWith("1600") || line1.StartsWith("1700") || line1.StartsWith("3500") || line1.StartsWith("3600") || line1.StartsWith("3700"))
                    {
                        LineNo++;
                        try
                        {
                            UniqueID = GetUniqueID();
                            //string[] dtSheet.Rows[k] = line1.Split(new string[] { dt.Rows[0]["SeparatorType"].ToString() }, StringSplitOptions.None);
                            Incr = 1;
                            TxnsCode = string.Empty;
                            TxnsCodeQ = string.Empty;
                            TxnsCSN = string.Empty;
                            AccountNumber = string.Empty;
                            AccountNumberExt = string.Empty;
                            FloorLimit = string.Empty;
                            ExceptionFile = string.Empty;
                            PCAS = string.Empty;
                            AcqReferenceNumber = string.Empty;
                            AcqBusinessID = string.Empty;
                            PurchaseDate = string.Empty;
                            DestAmount = string.Empty;
                            DestCCY = string.Empty;
                            SrcAmount = string.Empty;
                            SrcCCY = string.Empty;
                            MarchantName = string.Empty;
                            MarchantCity = string.Empty;
                            MarchantCountryCode = string.Empty;
                            MarchantCateCode = string.Empty;
                            MarchantZIPCode = string.Empty;
                            MarchantSPCode = string.Empty;
                            ReqPaymentService = string.Empty;
                            NoOfPaymentForm = string.Empty;
                            UsageCode = string.Empty;
                            ReasonCode = string.Empty;
                            SettlementFlag = string.Empty;
                            AuthCharIndicator = string.Empty;
                            AuthCode = string.Empty;
                            POSTerminalCapability = string.Empty;
                            Reserved1 = string.Empty;
                            CardHolderID = string.Empty;
                            CollectionOnlyFlag = string.Empty;
                            POSEntryMode = string.Empty;
                            CentralProcessDate = string.Empty;
                            ReimbursementAttribute = string.Empty;
                            BusinessFC = string.Empty;
                            TokanAssuranceLevel = string.Empty;
                            Reserved2 = string.Empty;
                            ChargebackRefNo = string.Empty;
                            DocIndicator = string.Empty;
                            MemMsgText = string.Empty;
                            SpecialCondition = string.Empty;
                            FeeProgram = string.Empty;
                            IssuerCharge = string.Empty;
                            Reserved3 = string.Empty;
                            CardAcceptorID = string.Empty;
                            TerminalID = string.Empty;
                            NationalRBFee = string.Empty;
                            MPECIndicator = string.Empty;
                            SpecialChargeback = string.Empty;
                            IntTraceNumber = string.Empty;
                            AcceptTerminal = string.Empty;
                            PrepaidCard = string.Empty;
                            ServiceDevlopmentField = string.Empty;
                            AVSResponseCode = string.Empty;
                            AuthSourceCode = string.Empty;
                            PurchaseIdenFormat = string.Empty;
                            AccountSelection = string.Empty;
                            InstallmentPayCount = string.Empty;
                            PurchaseIdentifier = string.Empty;
                            CashBack = string.Empty;
                            ChipConCode = string.Empty;
                            POSEnviroment = string.Empty;
                            TxnsIdentifier = string.Empty;
                            AuthAmount = string.Empty;
                            AuthCCY = string.Empty;
                            AuthResponseCode = string.Empty;
                            ValidationCode = string.Empty;
                            ExcludedTxnsIdenReason = string.Empty;
                            CRSProcessCode = string.Empty;
                            ChargeRight = string.Empty;
                            MultiClearingSN = string.Empty;
                            MultiClearingSC = string.Empty;
                            MarketSADI = string.Empty;
                            TotalAuthAmount = string.Empty;
                            InformationIndicator = string.Empty;
                            MarchantTelephoneNumber = string.Empty;
                            AdditionalData = string.Empty;
                            MerchantVolume = string.Empty;
                            ElectronicsCGI = string.Empty;
                            MerchantVerValue = string.Empty;
                            InterchangeFeeAmount = string.Empty;
                            InterchangeFeeSign = string.Empty;
                            SCBCCYExchangeRate = string.Empty;
                            BCDCCYExhangeRate = string.Empty;
                            ISAAmount = string.Empty;
                            ProductID = string.Empty;
                            ProgramID = string.Empty;
                            DCCIndicator = string.Empty;
                            AccountTypeIdentification = string.Empty;
                            SpendQIndicator = string.Empty;
                            PanToken = string.Empty;
                            Reserved4 = string.Empty;
                            CVV2ResultCode = string.Empty;
                            ReserveField1 = string.Empty;
                            ReserveField2 = string.Empty;
                            ReserveField3 = string.Empty;
                            ReserveField4 = string.Empty;
                            ReserveField5 = string.Empty;
                            Reserved5 = string.Empty;
                            BusinessFCLG = string.Empty;
                            Reserved6 = string.Empty;
                            LodgingNo = string.Empty;
                            LodExtraCharge = string.Empty;
                            Reserved7 = string.Empty;
                            LodgingDate = string.Empty;
                            DailyRoomRate = string.Empty;
                            TotalTax = string.Empty;
                            PrepaidExpns = string.Empty;
                            FoodCharges = string.Empty;
                            FolioCashAdv = string.Empty;
                            RoomNight = string.Empty;
                            TotalRoomTax = string.Empty;
                            Reserved8 = string.Empty;
                            Reserved9 = string.Empty;
                            FastFundsIn = string.Empty;
                            BusinessFCCR = string.Empty;
                            BusinessAppID = string.Empty;
                            SourceOfFunds = string.Empty;
                            PaymentRevRC = string.Empty;
                            SenderRefNo = string.Empty;
                            SenderAcNo = string.Empty;
                            SenderName = string.Empty;
                            SenderAdd = string.Empty;
                            SenderCity = string.Empty;
                            SenderState = string.Empty;
                            SenderCountry = string.Empty;
                            AUniqueID = string.Empty;
                            Reserved10 = string.Empty;
                            BusinessFC4 = string.Empty;
                            NetIdCode = string.Empty;
                            ConforInfo = string.Empty;
                            AdjProceIn = string.Empty;
                            MsgReasonCode = string.Empty;
                            SurchargeAmnt = string.Empty;
                            SurCrDr = string.Empty;
                            VisaIUO = string.Empty;
                            Reserved11 = string.Empty;
                            SurAmntBillCCY = string.Empty;
                            MoneyTrfExchFee = string.Empty;
                            Reserved12 = string.Empty;
                            LocalTax = string.Empty;
                            LocalTaxIn = string.Empty;
                            NtlTax = string.Empty;
                            NtlTaxIn = string.Empty;
                            BusinessRefNo = string.Empty;
                            CustVATRegNo = string.Empty;
                            Reserved13 = string.Empty;
                            SummaryCommCode = string.Empty;
                            OtherTax = string.Empty;
                            MsgID = string.Empty;
                            TimeOfPurchase = string.Empty;
                            CustCode = string.Empty;
                            NonFuelProdCode1 = string.Empty;
                            NonFuelProdCode2 = string.Empty;
                            NonFuelProdCode3 = string.Empty;
                            NonFuelProdCode4 = string.Empty;
                            NonFuelProdCode5 = string.Empty;
                            NonFuelProdCode6 = string.Empty;
                            NonFuelProdCode7 = string.Empty;
                            NonFuelProdCode8 = string.Empty;
                            MerPostCode = string.Empty;
                            Reserved14 = string.Empty;
                            TxnsType = string.Empty;
                            CardSeqNo = string.Empty;
                            TerminalTxnsDate = string.Empty;
                            TerminalCapProfile = string.Empty;
                            TerminalCountryCode = string.Empty;
                            TerminalSerialNo = string.Empty;
                            UnpredictableNo = string.Empty;
                            AppTxnsCounter = string.Empty;
                            AppIntProfile = string.Empty;
                            Cryptogram = string.Empty;
                            IssuerAppData2 = string.Empty;
                            IssuerAppData3 = string.Empty;
                            TerminalVerResult = string.Empty;
                            IssuerAppData47 = string.Empty;
                            CryptogramAmount = string.Empty;
                            IssuerAppData8 = string.Empty;
                            IssuerAppData916 = string.Empty;
                            IssuerAppData1 = string.Empty;
                            IssuerAppData17 = string.Empty;
                            IssuerAppData1832 = string.Empty;
                            FormFactInd = string.Empty;
                            IssuerScriptResults = string.Empty;


                            TCR = string.Empty;
                            TxnsNo = false;

                            for (int i = 0; i < 7; i++)
                            {
                                line1 = Regex.Replace(TotalCountArray[line + i].ToString(), "[^ -~]+", string.Empty);

                                if (ds.Tables["TxnsCSN"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsCSN"].Rows[0]["Length"].ToString() != "0")
                                {
                                    Start = int.Parse(ds.Tables["TxnsCSN"].Rows[0]["StartPosition"].ToString());
                                    End = int.Parse(ds.Tables["TxnsCSN"].Rows[0]["Length"].ToString());
                                    TCR = line1.Substring(Start - Incr, End);
                                }

                                if (TxnsNo && TCR == "0")
                                {
                                    break;
                                }

                                #region TCR0
                                if (TCR == "0")
                                {
                                    TxnsNo = true;
                                    if (ds.Tables["TxnsCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TxnsCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TxnsCode"].Rows[0]["Length"].ToString());
                                        TxnsCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TxnsCodeQ"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsCodeQ"].Rows[0]["Length"].ToString() != "0")
                                    {

                                        Start = int.Parse(ds.Tables["TxnsCodeQ"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TxnsCodeQ"].Rows[0]["Length"].ToString());
                                        TxnsCodeQ = line1.Substring(Start - Incr, End);

                                    }
                                    if (ds.Tables["TxnsCSN"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsCSN"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TxnsCSN"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TxnsCSN"].Rows[0]["Length"].ToString());
                                        TxnsCSN = line1.Substring(Start - Incr, End);

                                    }
                                    if (ds.Tables["AccountNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AccountNumber"].Rows[0]["Length"].ToString() != "0")
                                    {

                                        Start = int.Parse(ds.Tables["AccountNumber"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AccountNumber"].Rows[0]["Length"].ToString());
                                        AccountNumber = line1.Substring(Start - Incr, End);


                                    }
                                    if (ds.Tables["AccountNumberExt"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AccountNumberExt"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AccountNumberExt"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AccountNumberExt"].Rows[0]["Length"].ToString());
                                        AccountNumberExt = line1.Substring(Start - Incr, End);

                                    }
                                    if (ds.Tables["FloorLimit"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FloorLimit"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["FloorLimit"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["FloorLimit"].Rows[0]["Length"].ToString());
                                        FloorLimit = line1.Substring(Start - Incr, End);

                                    }
                                    if (ds.Tables["ExceptionFile"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ExceptionFile"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ExceptionFile"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ExceptionFile"].Rows[0]["Length"].ToString());
                                        ExceptionFile = line1.Substring(Start - Incr, End);

                                    }
                                    if (ds.Tables["PCAS"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PCAS"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["PCAS"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["PCAS"].Rows[0]["Length"].ToString());
                                        PCAS = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AcqReferenceNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AcqReferenceNumber"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AcqReferenceNumber"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AcqReferenceNumber"].Rows[0]["Length"].ToString());
                                        AcqReferenceNumber = line1.Substring(Start - Incr, End);
                                        //if (AcqReferenceNumber =="74214250272000122087207")
                                        //{

                                        //}
                                    }
                                    if (ds.Tables["AcqBusinessID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AcqBusinessID"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AcqBusinessID"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AcqBusinessID"].Rows[0]["Length"].ToString());
                                        AcqBusinessID = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["PurchaseDate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PurchaseDate"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["PurchaseDate"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["PurchaseDate"].Rows[0]["Length"].ToString());
                                        PurchaseDate = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["DestAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DestAmount"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["DestAmount"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["DestAmount"].Rows[0]["Length"].ToString());

                                        DestAmount = line1.Substring(Start - Incr, End);

                                    }
                                    if (ds.Tables["DestCCY"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DestCCY"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["DestCCY"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["DestCCY"].Rows[0]["Length"].ToString());
                                        DestCCY = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SrcAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SrcAmount"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SrcAmount"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SrcAmount"].Rows[0]["Length"].ToString());
                                        SrcAmount = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SrcCCY"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SrcCCY"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SrcCCY"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SrcCCY"].Rows[0]["Length"].ToString());
                                        SrcCCY = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MarchantName"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantName"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MarchantName"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MarchantName"].Rows[0]["Length"].ToString());
                                        MarchantName = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MarchantCity"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantCity"].Rows[0]["Length"].ToString() != "0")
                                    {

                                        Start = int.Parse(ds.Tables["MarchantCity"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MarchantCity"].Rows[0]["Length"].ToString());
                                        MarchantCity = line1.Substring(Start - Incr, End);

                                    }
                                    if (ds.Tables["MarchantCountryCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantCountryCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MarchantCountryCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MarchantCountryCode"].Rows[0]["Length"].ToString());
                                        MarchantCountryCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MarchantCateCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantCateCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MarchantCateCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MarchantCateCode"].Rows[0]["Length"].ToString());
                                        MarchantCateCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MarchantZIPCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantZIPCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MarchantZIPCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MarchantZIPCode"].Rows[0]["Length"].ToString());
                                        MarchantZIPCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MarchantSPCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantSPCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MarchantSPCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MarchantSPCode"].Rows[0]["Length"].ToString());
                                        MarchantSPCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ReqPaymentService"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReqPaymentService"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ReqPaymentService"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ReqPaymentService"].Rows[0]["Length"].ToString());
                                        ReqPaymentService = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NoOfPaymentForm"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NoOfPaymentForm"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NoOfPaymentForm"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NoOfPaymentForm"].Rows[0]["Length"].ToString());
                                        NoOfPaymentForm = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["UsageCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["UsageCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["UsageCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["UsageCode"].Rows[0]["Length"].ToString());
                                        UsageCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ReasonCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReasonCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ReasonCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ReasonCode"].Rows[0]["Length"].ToString());
                                        ReasonCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SettlementFlag"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SettlementFlag"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SettlementFlag"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SettlementFlag"].Rows[0]["Length"].ToString());
                                        SettlementFlag = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AuthCharIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthCharIndicator"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AuthCharIndicator"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AuthCharIndicator"].Rows[0]["Length"].ToString());
                                        AuthCharIndicator = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AuthCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AuthCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AuthCode"].Rows[0]["Length"].ToString());
                                        AuthCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["POSTerminalCapability"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["POSTerminalCapability"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["POSTerminalCapability"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["POSTerminalCapability"].Rows[0]["Length"].ToString());
                                        POSTerminalCapability = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved1"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["Reserved1"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["Reserved1"].Rows[0]["Length"].ToString());
                                        Reserved1 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CardHolderID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardHolderID"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CardHolderID"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CardHolderID"].Rows[0]["Length"].ToString());
                                        CardHolderID = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CollectionOnlyFlag"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CollectionOnlyFlag"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CollectionOnlyFlag"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CollectionOnlyFlag"].Rows[0]["Length"].ToString());
                                        CollectionOnlyFlag = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["POSEntryMode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["POSEntryMode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["POSEntryMode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["POSEntryMode"].Rows[0]["Length"].ToString());
                                        POSEntryMode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CentralProcessDate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CentralProcessDate"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CentralProcessDate"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CentralProcessDate"].Rows[0]["Length"].ToString());
                                        CentralProcessDate = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ReimbursementAttribute"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ReimbursementAttribute"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ReimbursementAttribute"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ReimbursementAttribute"].Rows[0]["Length"].ToString());
                                        ReimbursementAttribute = line1.Substring(Start - Incr, End);
                                    }

                                }
                                #endregion TCR0

                                #region TCR1
                                if (TCR == "1")
                                {
                                    if (ds.Tables["BusinessFC"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFC"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["BusinessFC"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["BusinessFC"].Rows[0]["Length"].ToString());
                                        BusinessFC = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TokanAssuranceLevel"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TokanAssuranceLevel"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TokanAssuranceLevel"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TokanAssuranceLevel"].Rows[0]["Length"].ToString());
                                        TokanAssuranceLevel = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved2"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["Reserved2"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["Reserved2"].Rows[0]["Length"].ToString());
                                        Reserved2 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ChargebackRefNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ChargebackRefNo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ChargebackRefNo"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ChargebackRefNo"].Rows[0]["Length"].ToString());
                                        ChargebackRefNo = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["DocIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DocIndicator"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["DocIndicator"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["DocIndicator"].Rows[0]["Length"].ToString());
                                        DocIndicator = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MemMsgText"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MemMsgText"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MemMsgText"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MemMsgText"].Rows[0]["Length"].ToString());
                                        MemMsgText = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SpecialCondition"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SpecialCondition"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SpecialCondition"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SpecialCondition"].Rows[0]["Length"].ToString());
                                        SpecialCondition = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["FeeProgram"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FeeProgram"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["FeeProgram"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["FeeProgram"].Rows[0]["Length"].ToString());
                                        FeeProgram = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerCharge"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerCharge"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerCharge"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerCharge"].Rows[0]["Length"].ToString());
                                        IssuerCharge = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved3"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved3"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["Reserved3"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["Reserved3"].Rows[0]["Length"].ToString());
                                        Reserved3 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CardAcceptorID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardAcceptorID"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CardAcceptorID"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CardAcceptorID"].Rows[0]["Length"].ToString());
                                        CardAcceptorID = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TerminalID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalID"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TerminalID"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TerminalID"].Rows[0]["Length"].ToString());
                                        TerminalID = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NationalRBFee"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NationalRBFee"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NationalRBFee"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NationalRBFee"].Rows[0]["Length"].ToString());
                                        NationalRBFee = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MPECIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MPECIndicator"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MPECIndicator"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MPECIndicator"].Rows[0]["Length"].ToString());
                                        MPECIndicator = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SpecialChargeback"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SpecialChargeback"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SpecialChargeback"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SpecialChargeback"].Rows[0]["Length"].ToString());
                                        SpecialChargeback = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IntTraceNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IntTraceNumber"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IntTraceNumber"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IntTraceNumber"].Rows[0]["Length"].ToString());
                                        IntTraceNumber = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AcceptTerminal"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AcceptTerminal"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AcceptTerminal"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AcceptTerminal"].Rows[0]["Length"].ToString());
                                        AcceptTerminal = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["PrepaidCard"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PrepaidCard"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["PrepaidCard"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["PrepaidCard"].Rows[0]["Length"].ToString());
                                        PrepaidCard = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ServiceDevlopmentField"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ServiceDevlopmentField"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ServiceDevlopmentField"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ServiceDevlopmentField"].Rows[0]["Length"].ToString());
                                        ServiceDevlopmentField = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AVSResponseCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AVSResponseCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AVSResponseCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AVSResponseCode"].Rows[0]["Length"].ToString());
                                        AVSResponseCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AuthSourceCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthSourceCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AuthSourceCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AuthSourceCode"].Rows[0]["Length"].ToString());
                                        AuthSourceCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["PurchaseIdenFormat"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PurchaseIdenFormat"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["PurchaseIdenFormat"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["PurchaseIdenFormat"].Rows[0]["Length"].ToString());
                                        PurchaseIdenFormat = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AccountSelection"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AccountSelection"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AccountSelection"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AccountSelection"].Rows[0]["Length"].ToString());
                                        AccountSelection = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["InstallmentPayCount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InstallmentPayCount"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["InstallmentPayCount"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["InstallmentPayCount"].Rows[0]["Length"].ToString());
                                        InstallmentPayCount = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["PurchaseIdentifier"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PurchaseIdentifier"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["PurchaseIdentifier"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["PurchaseIdentifier"].Rows[0]["Length"].ToString());
                                        PurchaseIdentifier = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CashBack"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CashBack"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CashBack"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CashBack"].Rows[0]["Length"].ToString());
                                        CashBack = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ChipConCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ChipConCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ChipConCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ChipConCode"].Rows[0]["Length"].ToString());
                                        ChipConCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["POSEnviroment"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["POSEnviroment"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["POSEnviroment"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["POSEnviroment"].Rows[0]["Length"].ToString());
                                        POSEnviroment = line1.Substring(Start - Incr, End);
                                    }
                                }
                                #endregion TCR1

                                #region TCR3
                                if (TCR == "3")
                                {
                                    if (ds.Tables["BusinessFCLG"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFCLG"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["BusinessFCLG"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["BusinessFCLG"].Rows[0]["Length"].ToString());
                                        BusinessFCLG = line1.Substring(Start - Incr, End);
                                    }

                                    if (BusinessFCLG == "LG")
                                    {

                                        if (ds.Tables["Reserved5"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved5"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["Reserved5"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["Reserved5"].Rows[0]["Length"].ToString());
                                            Reserved5 = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["BusinessFCLG"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFCLG"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["BusinessFCLG"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["BusinessFCLG"].Rows[0]["Length"].ToString());
                                            BusinessFCLG = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["Reserved6"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved6"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["Reserved6"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["Reserved6"].Rows[0]["Length"].ToString());
                                            Reserved6 = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["LodgingNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LodgingNo"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["LodgingNo"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["LodgingNo"].Rows[0]["Length"].ToString());
                                            LodgingNo = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["LodExtraCharge"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LodExtraCharge"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["LodExtraCharge"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["LodExtraCharge"].Rows[0]["Length"].ToString());
                                            LodExtraCharge = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["Reserved7"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved7"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["Reserved7"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["Reserved7"].Rows[0]["Length"].ToString());
                                            Reserved7 = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["LodgingDate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LodgingDate"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["LodgingDate"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["LodgingDate"].Rows[0]["Length"].ToString());
                                            LodgingDate = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["DailyRoomRate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DailyRoomRate"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["DailyRoomRate"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["DailyRoomRate"].Rows[0]["Length"].ToString());
                                            DailyRoomRate = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["TotalTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TotalTax"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["TotalTax"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["TotalTax"].Rows[0]["Length"].ToString());
                                            TotalTax = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["PrepaidExpns"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PrepaidExpns"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["PrepaidExpns"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["PrepaidExpns"].Rows[0]["Length"].ToString());
                                            PrepaidExpns = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["FoodCharges"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FoodCharges"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["FoodCharges"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["FoodCharges"].Rows[0]["Length"].ToString());
                                            FoodCharges = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["FolioCashAdv"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FolioCashAdv"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["FolioCashAdv"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["FolioCashAdv"].Rows[0]["Length"].ToString());
                                            FolioCashAdv = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["RoomNight"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["RoomNight"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["RoomNight"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["RoomNight"].Rows[0]["Length"].ToString());
                                            RoomNight = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["TotalRoomTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TotalRoomTax"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["TotalRoomTax"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["TotalRoomTax"].Rows[0]["Length"].ToString());
                                            TotalRoomTax = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["Reserved8"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved8"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["Reserved8"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["Reserved8"].Rows[0]["Length"].ToString());
                                            Reserved8 = line1.Substring(Start - Incr, End);
                                        }
                                    }
                                    if (BusinessFCLG == "CR")
                                    {
                                        if (ds.Tables["Reserved9"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved9"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["Reserved9"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["Reserved9"].Rows[0]["Length"].ToString());
                                            Reserved9 = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["FastFundsIn"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FastFundsIn"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["FastFundsIn"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["FastFundsIn"].Rows[0]["Length"].ToString());
                                            FastFundsIn = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["BusinessFCCR"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFCCR"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["BusinessFCCR"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["BusinessFCCR"].Rows[0]["Length"].ToString());
                                            BusinessFCCR = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["BusinessAppID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessAppID"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["BusinessAppID"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["BusinessAppID"].Rows[0]["Length"].ToString());
                                            BusinessAppID = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["SourceOfFunds"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SourceOfFunds"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["SourceOfFunds"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["SourceOfFunds"].Rows[0]["Length"].ToString());
                                            SourceOfFunds = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["PaymentRevRC"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PaymentRevRC"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["PaymentRevRC"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["PaymentRevRC"].Rows[0]["Length"].ToString());
                                            PaymentRevRC = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["SenderRefNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderRefNo"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["SenderRefNo"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["SenderRefNo"].Rows[0]["Length"].ToString());
                                            SenderRefNo = line1.Substring(Start - Incr, End);
                                        }


                                        if (ds.Tables["SenderAcNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderAcNo"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["SenderAcNo"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["SenderAcNo"].Rows[0]["Length"].ToString());
                                            SenderAcNo = line1.Substring(Start - Incr, End);
                                        }

                                        if (ds.Tables["SenderName"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderName"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["SenderName"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["SenderName"].Rows[0]["Length"].ToString());
                                            SenderName = line1.Substring(Start - Incr, End);
                                        }

                                        if (ds.Tables["SenderAdd"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderAdd"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["SenderAdd"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["SenderAdd"].Rows[0]["Length"].ToString());
                                            SenderAdd = line1.Substring(Start - Incr, End);
                                        }

                                        if (ds.Tables["SenderCity"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderCity"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["SenderCity"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["SenderCity"].Rows[0]["Length"].ToString());
                                            SenderCity = line1.Substring(Start - Incr, End);
                                        }

                                        if (ds.Tables["SenderState"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderState"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["SenderState"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["SenderState"].Rows[0]["Length"].ToString());
                                            SenderState = line1.Substring(Start - Incr, End);
                                        }
                                        if (ds.Tables["SenderCountry"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SenderCountry"].Rows[0]["Length"].ToString() != "0")
                                        {
                                            Start = int.Parse(ds.Tables["SenderCountry"].Rows[0]["StartPosition"].ToString());
                                            End = int.Parse(ds.Tables["SenderCountry"].Rows[0]["Length"].ToString());
                                            SenderCountry = line1.Substring(Start - Incr, End);
                                        }

                                    }



                                }
                                #endregion TCR3

                                #region TCR4
                                if (TCR == "4")
                                {
                                    if (ds.Tables["AUniqueID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AUniqueID"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AUniqueID"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AUniqueID"].Rows[0]["Length"].ToString());
                                        AUniqueID = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved10"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved10"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["Reserved10"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["Reserved10"].Rows[0]["Length"].ToString());
                                        Reserved10 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["BusinessFC4"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessFC4"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["BusinessFC4"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["BusinessFC4"].Rows[0]["Length"].ToString());
                                        BusinessFC4 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NetIdCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NetIdCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NetIdCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NetIdCode"].Rows[0]["Length"].ToString());
                                        NetIdCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ConforInfo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ConforInfo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ConforInfo"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ConforInfo"].Rows[0]["Length"].ToString());
                                        ConforInfo = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AdjProceIn"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AdjProceIn"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AdjProceIn"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AdjProceIn"].Rows[0]["Length"].ToString());
                                        AdjProceIn = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MsgReasonCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MsgReasonCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MsgReasonCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MsgReasonCode"].Rows[0]["Length"].ToString());
                                        MsgReasonCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SurchargeAmnt"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SurchargeAmnt"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SurchargeAmnt"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SurchargeAmnt"].Rows[0]["Length"].ToString());
                                        SurchargeAmnt = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SurCrDr"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SurCrDr"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SurCrDr"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SurCrDr"].Rows[0]["Length"].ToString());
                                        SurCrDr = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["VisaIUO"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["VisaIUO"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["VisaIUO"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["VisaIUO"].Rows[0]["Length"].ToString());
                                        VisaIUO = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved11"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved11"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["Reserved11"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["Reserved11"].Rows[0]["Length"].ToString());
                                        Reserved11 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SurAmntBillCCY"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SurAmntBillCCY"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SurAmntBillCCY"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SurAmntBillCCY"].Rows[0]["Length"].ToString());
                                        SurAmntBillCCY = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MoneyTrfExchFee"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MoneyTrfExchFee"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MoneyTrfExchFee"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MoneyTrfExchFee"].Rows[0]["Length"].ToString());
                                        MoneyTrfExchFee = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved12"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved12"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["Reserved12"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["Reserved12"].Rows[0]["Length"].ToString());
                                        Reserved12 = line1.Substring(Start - Incr, End);
                                    }

                                }
                                #endregion TCR4

                                #region TCR5
                                if (TCR == "5")
                                {
                                    if (ds.Tables["TxnsIdentifier"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsIdentifier"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TxnsIdentifier"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TxnsIdentifier"].Rows[0]["Length"].ToString());
                                        TxnsIdentifier = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AuthAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthAmount"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AuthAmount"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AuthAmount"].Rows[0]["Length"].ToString());
                                        AuthAmount = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AuthCCY"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthCCY"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AuthCCY"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AuthCCY"].Rows[0]["Length"].ToString());
                                        AuthCCY = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AuthResponseCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AuthResponseCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AuthResponseCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AuthResponseCode"].Rows[0]["Length"].ToString());
                                        AuthResponseCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ValidationCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ValidationCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ValidationCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ValidationCode"].Rows[0]["Length"].ToString());
                                        ValidationCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ExcludedTxnsIdenReason"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ExcludedTxnsIdenReason"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ExcludedTxnsIdenReason"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ExcludedTxnsIdenReason"].Rows[0]["Length"].ToString());
                                        ExcludedTxnsIdenReason = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CRSProcessCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CRSProcessCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CRSProcessCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CRSProcessCode"].Rows[0]["Length"].ToString());
                                        CRSProcessCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ChargeRight"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ChargeRight"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ChargeRight"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ChargeRight"].Rows[0]["Length"].ToString());
                                        ChargeRight = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MultiClearingSN"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MultiClearingSN"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MultiClearingSN"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MultiClearingSN"].Rows[0]["Length"].ToString());
                                        MultiClearingSN = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MultiClearingSC"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MultiClearingSC"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MultiClearingSC"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MultiClearingSC"].Rows[0]["Length"].ToString());
                                        MultiClearingSC = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MarketSADI"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarketSADI"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MarketSADI"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MarketSADI"].Rows[0]["Length"].ToString());
                                        MarketSADI = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TotalAuthAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TotalAuthAmount"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TotalAuthAmount"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TotalAuthAmount"].Rows[0]["Length"].ToString());
                                        TotalAuthAmount = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["InformationIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InformationIndicator"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["InformationIndicator"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["InformationIndicator"].Rows[0]["Length"].ToString());
                                        InformationIndicator = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MarchantTelephoneNumber"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MarchantTelephoneNumber"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MarchantTelephoneNumber"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MarchantTelephoneNumber"].Rows[0]["Length"].ToString());
                                        MarchantTelephoneNumber = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AdditionalData"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AdditionalData"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AdditionalData"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AdditionalData"].Rows[0]["Length"].ToString());
                                        AdditionalData = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MerchantVolume"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MerchantVolume"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MerchantVolume"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MerchantVolume"].Rows[0]["Length"].ToString());
                                        MerchantVolume = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ElectronicsCGI"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ElectronicsCGI"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ElectronicsCGI"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ElectronicsCGI"].Rows[0]["Length"].ToString());
                                        ElectronicsCGI = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MerchantVerValue"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MerchantVerValue"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MerchantVerValue"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MerchantVerValue"].Rows[0]["Length"].ToString());
                                        MerchantVerValue = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["InterchangeFeeAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InterchangeFeeAmount"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["InterchangeFeeAmount"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["InterchangeFeeAmount"].Rows[0]["Length"].ToString());
                                        InterchangeFeeAmount = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["InterchangeFeeSign"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["InterchangeFeeSign"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["InterchangeFeeSign"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["InterchangeFeeSign"].Rows[0]["Length"].ToString());
                                        InterchangeFeeSign = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SCBCCYExchangeRate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SCBCCYExchangeRate"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SCBCCYExchangeRate"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SCBCCYExchangeRate"].Rows[0]["Length"].ToString());
                                        SCBCCYExchangeRate = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["BCDCCYExhangeRate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BCDCCYExhangeRate"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["BCDCCYExhangeRate"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["BCDCCYExhangeRate"].Rows[0]["Length"].ToString());
                                        BCDCCYExhangeRate = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ISAAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ISAAmount"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ISAAmount"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ISAAmount"].Rows[0]["Length"].ToString());
                                        ISAAmount = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ProductID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ProductID"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ProductID"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ProductID"].Rows[0]["Length"].ToString());
                                        ProductID = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["ProgramID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["ProgramID"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["ProgramID"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["ProgramID"].Rows[0]["Length"].ToString());
                                        ProgramID = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["DCCIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["DCCIndicator"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["DCCIndicator"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["DCCIndicator"].Rows[0]["Length"].ToString());
                                        DCCIndicator = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AccountTypeIdentification"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AccountTypeIdentification"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AccountTypeIdentification"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AccountTypeIdentification"].Rows[0]["Length"].ToString());
                                        AccountTypeIdentification = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SpendQIndicator"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SpendQIndicator"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SpendQIndicator"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SpendQIndicator"].Rows[0]["Length"].ToString());
                                        SpendQIndicator = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["PanToken"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["PanToken"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["PanToken"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["PanToken"].Rows[0]["Length"].ToString());
                                        PanToken = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CVV2ResultCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CVV2ResultCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CVV2ResultCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CVV2ResultCode"].Rows[0]["Length"].ToString());
                                        CVV2ResultCode = line1.Substring(Start - Incr, End);
                                    }
                                }
                                #endregion TCR5

                                #region TCR6
                                if (TCR == "6")
                                {
                                    if (ds.Tables["LocalTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LocalTax"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["LocalTax"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["LocalTax"].Rows[0]["Length"].ToString());
                                        LocalTax = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["LocalTaxIn"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["LocalTaxIn"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["LocalTaxIn"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["LocalTaxIn"].Rows[0]["Length"].ToString());
                                        LocalTaxIn = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NtlTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NtlTax"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NtlTax"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NtlTax"].Rows[0]["Length"].ToString());
                                        NtlTax = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NtlTaxIn"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NtlTaxIn"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NtlTaxIn"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NtlTaxIn"].Rows[0]["Length"].ToString());
                                        NtlTaxIn = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["BusinessRefNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["BusinessRefNo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["BusinessRefNo"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["BusinessRefNo"].Rows[0]["Length"].ToString());
                                        BusinessRefNo = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CustVATRegNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CustVATRegNo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CustVATRegNo"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CustVATRegNo"].Rows[0]["Length"].ToString());
                                        CustVATRegNo = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved13"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved13"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["Reserved13"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["Reserved13"].Rows[0]["Length"].ToString());
                                        Reserved13 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["SummaryCommCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["SummaryCommCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["SummaryCommCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["SummaryCommCode"].Rows[0]["Length"].ToString());
                                        SummaryCommCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["OtherTax"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["OtherTax"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["OtherTax"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["OtherTax"].Rows[0]["Length"].ToString());
                                        OtherTax = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MsgID"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MsgID"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MsgID"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MsgID"].Rows[0]["Length"].ToString());
                                        MsgID = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TimeOfPurchase"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TimeOfPurchase"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TimeOfPurchase"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TimeOfPurchase"].Rows[0]["Length"].ToString());
                                        TimeOfPurchase = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CustCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CustCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CustCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CustCode"].Rows[0]["Length"].ToString());
                                        CustCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NonFuelProdCode1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode1"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NonFuelProdCode1"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NonFuelProdCode1"].Rows[0]["Length"].ToString());
                                        NonFuelProdCode1 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NonFuelProdCode2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode2"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NonFuelProdCode2"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NonFuelProdCode2"].Rows[0]["Length"].ToString());
                                        NonFuelProdCode2 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NonFuelProdCode3"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode3"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NonFuelProdCode3"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NonFuelProdCode3"].Rows[0]["Length"].ToString());
                                        NonFuelProdCode3 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NonFuelProdCode4"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode4"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NonFuelProdCode4"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NonFuelProdCode4"].Rows[0]["Length"].ToString());
                                        NonFuelProdCode4 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NonFuelProdCode5"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode5"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NonFuelProdCode5"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NonFuelProdCode5"].Rows[0]["Length"].ToString());
                                        NonFuelProdCode5 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NonFuelProdCode6"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode6"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NonFuelProdCode6"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NonFuelProdCode6"].Rows[0]["Length"].ToString());
                                        NonFuelProdCode6 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NonFuelProdCode7"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode7"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NonFuelProdCode7"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NonFuelProdCode7"].Rows[0]["Length"].ToString());
                                        NonFuelProdCode7 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["NonFuelProdCode8"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["NonFuelProdCode8"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["NonFuelProdCode8"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["NonFuelProdCode8"].Rows[0]["Length"].ToString());
                                        NonFuelProdCode8 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["MerPostCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["MerPostCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["MerPostCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["MerPostCode"].Rows[0]["Length"].ToString());
                                        MerPostCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Reserved14"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Reserved14"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["Reserved14"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["Reserved14"].Rows[0]["Length"].ToString());
                                        Reserved14 = line1.Substring(Start - Incr, End);
                                    }

                                }
                                #endregion TCR6

                                #region TCR7
                                if (TCR == "7")
                                {
                                    if (ds.Tables["TxnsType"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TxnsType"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TxnsType"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TxnsType"].Rows[0]["Length"].ToString());
                                        TxnsType = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CardSeqNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CardSeqNo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CardSeqNo"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CardSeqNo"].Rows[0]["Length"].ToString());
                                        CardSeqNo = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TerminalTxnsDate"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalTxnsDate"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TerminalTxnsDate"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TerminalTxnsDate"].Rows[0]["Length"].ToString());
                                        TerminalTxnsDate = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TerminalCapProfile"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalCapProfile"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TerminalCapProfile"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TerminalCapProfile"].Rows[0]["Length"].ToString());
                                        TerminalCapProfile = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TerminalCountryCode"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalCountryCode"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TerminalCountryCode"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TerminalCountryCode"].Rows[0]["Length"].ToString());
                                        TerminalCountryCode = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TerminalSerialNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalSerialNo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TerminalSerialNo"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TerminalSerialNo"].Rows[0]["Length"].ToString());
                                        TerminalSerialNo = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["UnpredictableNo"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["UnpredictableNo"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["UnpredictableNo"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["UnpredictableNo"].Rows[0]["Length"].ToString());
                                        UnpredictableNo = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AppTxnsCounter"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AppTxnsCounter"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AppTxnsCounter"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AppTxnsCounter"].Rows[0]["Length"].ToString());
                                        AppTxnsCounter = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["AppIntProfile"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["AppIntProfile"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["AppIntProfile"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["AppIntProfile"].Rows[0]["Length"].ToString());
                                        AppIntProfile = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["Cryptogram"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["Cryptogram"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["Cryptogram"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["Cryptogram"].Rows[0]["Length"].ToString());
                                        Cryptogram = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerAppData2"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData2"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerAppData2"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerAppData2"].Rows[0]["Length"].ToString());
                                        IssuerAppData2 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerAppData3"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData3"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerAppData3"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerAppData3"].Rows[0]["Length"].ToString());
                                        IssuerAppData3 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["TerminalVerResult"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["TerminalVerResult"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["TerminalVerResult"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["TerminalVerResult"].Rows[0]["Length"].ToString());
                                        TerminalVerResult = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerAppData47"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData47"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerAppData47"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerAppData47"].Rows[0]["Length"].ToString());
                                        IssuerAppData47 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["CryptogramAmount"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["CryptogramAmount"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["CryptogramAmount"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["CryptogramAmount"].Rows[0]["Length"].ToString());
                                        CryptogramAmount = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerAppData8"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData8"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerAppData8"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerAppData8"].Rows[0]["Length"].ToString());
                                        IssuerAppData8 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerAppData916"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData916"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerAppData916"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerAppData916"].Rows[0]["Length"].ToString());
                                        IssuerAppData916 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerAppData1"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData1"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerAppData1"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerAppData1"].Rows[0]["Length"].ToString());
                                        IssuerAppData1 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerAppData17"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData17"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerAppData17"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerAppData17"].Rows[0]["Length"].ToString());
                                        IssuerAppData17 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerAppData1832"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerAppData1832"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerAppData1832"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerAppData1832"].Rows[0]["Length"].ToString());
                                        IssuerAppData1832 = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["FormFactInd"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["FormFactInd"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["FormFactInd"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["FormFactInd"].Rows[0]["Length"].ToString());
                                        FormFactInd = line1.Substring(Start - Incr, End);
                                    }
                                    if (ds.Tables["IssuerScriptResults"].Rows[0]["StartPosition"].ToString() != "0" && ds.Tables["IssuerScriptResults"].Rows[0]["Length"].ToString() != "0")
                                    {
                                        Start = int.Parse(ds.Tables["IssuerScriptResults"].Rows[0]["StartPosition"].ToString());
                                        End = int.Parse(ds.Tables["IssuerScriptResults"].Rows[0]["Length"].ToString());
                                        IssuerScriptResults = line1.Substring(Start - Incr, End);
                                    }

                                }
                                #endregion TCR7

                            }


                            LodgingDateTime = null;
                            TerminalTxnsDateTime = null;

                            if (LodgingDate != "" && LodgingDate != "000000")
                            {
                                LodgingDateTime = DateTime.ParseExact(LodgingDate, "yyMMdd", CultureInfo.InvariantCulture);
                            }

                            if (TerminalTxnsDate != "")
                            {
                                TerminalTxnsDateTime = DateTime.ParseExact(TerminalTxnsDate, "yyMMdd", CultureInfo.InvariantCulture);
                            }




                            CardNumber = AccountNumber;
                            CardType = string.Empty;
                            ECardNumber = string.Empty;

                            PurchaseDate = PurchaseDate.Substring(2, 2) + "/" + PurchaseDate.Substring(0, 2) + "/" + fyear.ToString() + " 00:00:00";

                            TransactionDateTime = DateTime.ParseExact(PurchaseDate, "dd/MM/yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                            PurchaseDate = DateTime.Now.ToString();



                            #region InitilizedField

                            #endregion InitilizedField

                            if (CardNumber != "")
                            {
                                ECardNumber = AesEncryption.EncryptString(CardNumber);;
                            }

                            if (CardNumber != "")
                            {
                                CardNumber = CardNumber.Substring(0, 6) + "XXXXXXXXXX".Substring(1, CardNumber.Length - 10) + CardNumber.Substring(CardNumber.Length - 4, 4);
                            }


                            _DataTable0.Rows.Add(ClientID
                              , UniqueID
                              , TxnsCode
                              , TxnsCodeQ
                              , TxnsCSN
                              , CardNumber
                              , AccountNumberExt
                              , FloorLimit
                              , ExceptionFile
                              , PCAS
                              , AcqReferenceNumber
                              , AcqBusinessID
                              , TransactionDateTime
                              , Convert.ToDecimal(DestAmount)
                              , DestCCY
                              , Convert.ToDecimal(SrcAmount)
                              , SrcCCY
                              , MarchantName
                              , MarchantCity
                              , MarchantCountryCode
                              , MarchantCateCode
                              , MarchantZIPCode
                              , MarchantSPCode
                              , ReqPaymentService
                              , NoOfPaymentForm
                              , UsageCode
                              , ReasonCode
                              , SettlementFlag
                              , AuthCharIndicator
                              , AuthCode
                              , POSTerminalCapability
                              , Reserved1
                              , CardHolderID
                              , CollectionOnlyFlag
                              , POSEntryMode
                              , DateTime.Now
                              , ReimbursementAttribute
                              , ReserveField1
                              , ReserveField2
                              , ReserveField3
                              , ReserveField4
                              , ReserveField5
                              , RevEntryLeg
                              , 0
                              , FileName
                              , path
                              , FileDate
                              , DateTime.Now
                              , DateTime.Now
                              , UserName
                              , UserName
                              , ECardNumber
                              , CardScheme
                              , IssuingNetwork
                              );



                            _DataTable1.Rows.Add(ClientID
                              , UniqueID
                              , BusinessFC
                              , TokanAssuranceLevel
                              , Reserved2
                              , ChargebackRefNo
                              , DocIndicator
                              , MemMsgText
                              , SpecialCondition
                              , FeeProgram
                              , IssuerCharge
                              , Reserved3
                              , CardAcceptorID
                              , TerminalID
                              , NationalRBFee
                              , MPECIndicator
                              , SpecialChargeback
                              , IntTraceNumber
                              , AcceptTerminal
                              , PrepaidCard
                              , ServiceDevlopmentField
                              , AVSResponseCode
                              , AuthSourceCode
                              , PurchaseIdenFormat
                              , AccountSelection
                              , InstallmentPayCount
                              , PurchaseIdentifier
                              , CashBack
                              , ChipConCode
                              , POSEnviroment
                              , RevEntryLeg
                              , 0
                              );

                            if (BusinessFCLG != "")
                            {
                                _DataTable3.Rows.Add(ClientID
                              , UniqueID
                              , Reserved5
                              , BusinessFCLG
                              , Reserved6
                              , LodgingNo
                              , LodExtraCharge
                              , Reserved7
                              , LodgingDateTime
                              , DailyRoomRate
                              , TotalTax
                              , PrepaidExpns
                              , FoodCharges
                              , FolioCashAdv
                              , RoomNight
                              , TotalRoomTax
                              , Reserved8
                              , Reserved9
                              , FastFundsIn
                              , BusinessFCCR
                              , BusinessAppID
                              , SourceOfFunds
                              , PaymentRevRC
                              , SenderRefNo
                              , SenderAcNo
                              , SenderName
                              , SenderAdd
                              , SenderCity
                              , SenderState
                              , SenderCountry
                              , RevEntryLeg
                              , 0
                              );
                            }


                            if (AUniqueID != "")
                            {
                                _DataTable4.Rows.Add(ClientID
                              , UniqueID
                              , AUniqueID
                              , Reserved10
                              , BusinessFC4
                              , NetIdCode
                              , ConforInfo
                              , AdjProceIn
                              , MsgReasonCode
                              , SurchargeAmnt
                              , SurCrDr
                              , VisaIUO
                              , Reserved11
                              , SurAmntBillCCY
                              , MoneyTrfExchFee
                              , Reserved12
                              , RevEntryLeg
                              , 0
                              );
                            }




                            _DataTable5.Rows.Add(ClientID
                              , UniqueID
                              , TxnsIdentifier
                              , Convert.ToDecimal(AuthAmount)
                              , AuthCCY
                              , AuthResponseCode
                              , ValidationCode
                              , ExcludedTxnsIdenReason
                              , CRSProcessCode
                              , ChargeRight
                              , MultiClearingSN
                              , MultiClearingSC
                              , MarketSADI
                              , Convert.ToDecimal(TotalAuthAmount)
                              , InformationIndicator
                              , MarchantTelephoneNumber
                              , AdditionalData
                              , MerchantVolume
                              , ElectronicsCGI
                              , MerchantVerValue
                              , Convert.ToDecimal(InterchangeFeeAmount)
                              , InterchangeFeeSign
                              , Convert.ToDecimal(SCBCCYExchangeRate)
                              , Convert.ToDecimal(BCDCCYExhangeRate)
                              , Convert.ToDecimal(ISAAmount)
                              , ProductID
                              , ProgramID
                              , DCCIndicator
                              , AccountTypeIdentification
                              , SpendQIndicator
                              , PanToken
                              , Reserved4
                              , CVV2ResultCode
                              , RevEntryLeg
                              , 0
                              );

                            if (BusinessRefNo != "")
                            {
                                _DataTable6.Rows.Add(ClientID
                              , UniqueID
                              , LocalTax
                              , LocalTaxIn
                              , NtlTax
                              , NtlTaxIn
                              , BusinessRefNo
                              , CustVATRegNo
                              , Reserved13
                              , SummaryCommCode
                              , OtherTax
                              , MsgID
                              , TimeOfPurchase
                              , CustCode
                              , NonFuelProdCode1
                              , NonFuelProdCode2
                              , NonFuelProdCode3
                              , NonFuelProdCode4
                              , NonFuelProdCode5
                              , NonFuelProdCode6
                              , NonFuelProdCode7
                              , NonFuelProdCode8
                              , MerPostCode
                              , Reserved14
                              , RevEntryLeg
                              , 0
                              );


                            }


                            if (CardSeqNo != "")
                            {
                                _DataTable7.Rows.Add(ClientID
                                , UniqueID
                                , TxnsType
                                , CardSeqNo
                                , TerminalTxnsDate
                                , TerminalCapProfile
                                , TerminalCountryCode
                                , TerminalSerialNo
                                , UnpredictableNo
                                , AppTxnsCounter
                                , AppIntProfile
                                , Cryptogram
                                , IssuerAppData2
                                , IssuerAppData3
                                , TerminalVerResult
                                , IssuerAppData47
                                , CryptogramAmount
                                , IssuerAppData8
                                , IssuerAppData916
                                , IssuerAppData1
                                , IssuerAppData17
                                , IssuerAppData1832
                                , FormFactInd
                                , IssuerScriptResults
                                , RevEntryLeg
                                , 0
                                );

                            }


                        }
                        catch
                        {
                            // objLogWriter.FunErrorLog(ex.Message.ToString(), ClientCode, "VISA.cs", "SplitData", LineNo, FileName + line1, UserName, 'E');
                        }

                    }

                }



                if (_DataTable0.Rows.Count > 0)
                {
                    InsertCount = _DataTable0.Rows.Count + _DataTable1.Rows.Count + _DataTable3.Rows.Count + _DataTable4.Rows.Count + _DataTable5.Rows.Count + _DataTable6.Rows.Count + _DataTable7.Rows.Count + _DataTable1020.Rows.Count;
                    _DataSet.Tables.Add(_DataTable0);
                    _DataSet.Tables.Add(_DataTable1);
                    _DataSet.Tables.Add(_DataTable3);
                    _DataSet.Tables.Add(_DataTable4);
                    _DataSet.Tables.Add(_DataTable5);
                    _DataSet.Tables.Add(_DataTable6);
                    _DataSet.Tables.Add(_DataTable7);
                    _DataSet.Tables.Add(_DataTable1020);
                }
                //if (_DataTable1.Rows.Count > 0)
                //    {           
                //    _DataSet.Tables.Add(_DataTable1);
                //    }
                //if (_DataTable3.Rows.Count > 0)
                //    {
                //    _DataSet.Tables.Add(_DataTable3);
                //    }
                //if (_DataTable4.Rows.Count > 0)
                //    {
                //    _DataSet.Tables.Add(_DataTable4);
                //    }
                //if (_DataTable5.Rows.Count > 0)
                //    {
                //    _DataSet.Tables.Add(_DataTable5);
                //    }
                //if (_DataTable6.Rows.Count > 0)
                //    {
                //    _DataSet.Tables.Add(_DataTable6);
                //    }
                //if (_DataTable7.Rows.Count > 0)
                //    {
                //    _DataSet.Tables.Add(_DataTable7);
                //    }
            }
            catch (Exception EX)
            {
                DBLog.InsertLogs(EX.Message.ToString(), ClientID, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataSet;

        }

        public DataTable SplitDataAcquirer(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();

            InsertCount = 0;
            TotalCount = 0;

            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(string));
            _DataTable.Columns.Add("CARDNO", typeof(string));
            _DataTable.Columns.Add("REFNO", typeof(string));
            _DataTable.Columns.Add("TRACENO", typeof(string));
            _DataTable.Columns.Add("TERMINALISSUERID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("PROCESSINGCODE", typeof(string));
            _DataTable.Columns.Add("ENTMODE", typeof(string));
            _DataTable.Columns.Add("CNSTP", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("TAMOUNT", typeof(string));
            _DataTable.Columns.Add("SAMOUNT", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONID", typeof(string));
            _DataTable.Columns.Add("ROUTING", typeof(string));
            _DataTable.Columns.Add("ACTUALAMOUNT", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));

            string _TotalRecordsRow = string.Empty;
            string SplitType = ",";
            string _TR_TIMESTAMP = string.Empty;
            string _Cardnumber = string.Empty;
            string _referenceNumber = string.Empty;
            string _TraceNumber = string.Empty;
            string _TerminalOrIssuerId = string.Empty;
            string _TranType = string.Empty;
            string _ProcessingCode = string.Empty;
            string _EntMode = string.Empty;
            string _CNSTP = string.Empty;
            string _RespCode = string.Empty;
            string _TransactionAmount = string.Empty;
            string _SettelmentAmount = string.Empty;
            string _TERMINALID = string.Empty;
            string _TransactionID = string.Empty;
            string strAmount = string.Empty;
            string _Routing = string.Empty;
            string _FeeLevel = string.Empty;
            string _ActualAmmt = string.Empty;

            string _Stan = string.Empty;
            string _DrCrType = string.Empty;
            string[] TerminalCode;
            string[] BIN_No;

            int ClientID = 0;
            int ModeID = 1;
            int ChannelID = 10;

            string TIME = string.Empty;
            string TDATE = string.Empty;
            string month = string.Empty;
            string year = string.Empty;

            string TimeStamp = string.Empty;

            double mainamount = 0, amount = 0;

            int LineNo = 0;

            int StartIndex = -1;
            int EndIndex = -1;

            string CardScheme = "VISA";
            string IssuingNetwork = "VISA";
            string ECardNumber = string.Empty;

            DateTime TimeStamp1;

            try
            {
                DateTime CreatedDt = DateTime.Now;
                string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh:mm:ss tt");


                

                
                
                
                


                int _TotalRows = 0, _RecordID = 0;


                _TotalRows = 0;
                string[] LogFile = File.ReadAllLines(path, Encoding.Default);

                TotalCount = LogFile.Length;

                _TotalRows = LogFile.Length;

                DateTime FileDate1 = DateTime.ParseExact(LogFile[4].ToString().Substring(LogFile[4].Length - 8, 7), "ddMMMyy", CultureInfo.InvariantCulture);
                string FileDate = FileDate1.Day.ToString() + "-" + FileDate1.ToString("MMM") + "-" + FileDate1.ToString("yy") + FileDate1.ToString(" hh:mm:ss tt");

                year = "20" + LogFile[4].ToString().Substring(LogFile[4].Length - 3, 2);

                StartIndex = -1;
                EndIndex = -1;

                TerminalCode = dt.Rows[0]["TerminalCode"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                BIN_No = dt.Rows[0]["BIN_No"].ToString().Split(new string[] { SplitType }, StringSplitOptions.None);
                ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
                ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());
                ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());


                for (int j = 0; j < TotalCount; j++)
                {

                    StartIndex = Common.GetIndex(LogFile, j, "SMS601C");
                    EndIndex = Common.GetIndex(LogFile, StartIndex, "SMS601I");

                    if (StartIndex == -1)
                    {
                        break;
                    }


                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {
                                if (int.TryParse(LogFile[k].Substring(2, 2), out _RecordID))
                                {
                                    _TotalRecordsRow = string.Empty;
                                    SplitType = ",";
                                    _TR_TIMESTAMP = string.Empty;
                                    _Cardnumber = string.Empty;
                                    _referenceNumber = string.Empty;
                                    _TraceNumber = string.Empty;
                                    _TerminalOrIssuerId = string.Empty;
                                    _TranType = string.Empty;
                                    _ProcessingCode = string.Empty;
                                    _EntMode = string.Empty;
                                    _CNSTP = string.Empty;
                                    _RespCode = string.Empty;
                                    _TransactionAmount = string.Empty;
                                    _SettelmentAmount = string.Empty;
                                    _TERMINALID = string.Empty;
                                    _TransactionID = string.Empty;
                                    strAmount = string.Empty;
                                    _Routing = string.Empty;
                                    _FeeLevel = string.Empty;
                                    _ActualAmmt = string.Empty;
                                    _Stan = string.Empty;
                                    _DrCrType = string.Empty;



                                    LineNo++;
                                    _TotalRecordsRow = LogFile[k] + LogFile[k + 1] + LogFile[k + 2] + LogFile[k + 3];
                                    _TR_TIMESTAMP = _TotalRecordsRow.Substring(5, 5);
                                    TIME = _TotalRecordsRow.Substring(10, 9);
                                    TDATE = _TR_TIMESTAMP.Substring(0, 2);
                                    month = _TR_TIMESTAMP.Substring(2, 3).ToString();
                                    _TR_TIMESTAMP = TDATE + '-' + month + "-" + year + TIME;
                                    TimeStamp1 = DateTime.ParseExact(_TR_TIMESTAMP, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                    TimeStamp = TimeStamp1.Day.ToString() + "-" + TimeStamp1.ToString("MMM") + "-" + TimeStamp1.ToString("yy") + TimeStamp1.ToString(" hh:mm:ss tt");
                                    _Cardnumber = _TotalRecordsRow.Substring(20, 20);
                                    _referenceNumber = _TotalRecordsRow.Substring(40, 13).Trim();
                                    _Stan = _referenceNumber.Substring(_referenceNumber.Length - 6, 6);
                                    _TraceNumber = _TotalRecordsRow.Substring(53, 7);
                                    _TerminalOrIssuerId = _TotalRecordsRow.Substring(60, 8);
                                    _TranType = _TotalRecordsRow.Substring(72, 5);
                                    _ProcessingCode = _TotalRecordsRow.Substring(77, 7);
                                    _EntMode = _TotalRecordsRow.Substring(84, 9);
                                    _CNSTP = _TotalRecordsRow.Substring(93, 4);
                                    _RespCode = _TotalRecordsRow.Substring(97, 7);
                                    mainamount = double.Parse(_TotalRecordsRow.Substring(104, 7));
                                    _TransactionAmount = Convert.ToString(mainamount);
                                    _SettelmentAmount = _TotalRecordsRow.Substring(120, 29).Trim().Replace(",", string.Empty);
                                    _DrCrType = _SettelmentAmount.Substring(_SettelmentAmount.Length - 2);
                                    _SettelmentAmount = _SettelmentAmount.Substring(0, _SettelmentAmount.Length - 2);

                                    if (_SettelmentAmount == "0.")
                                    {
                                        _SettelmentAmount = "0.00";
                                    }
                                    _TERMINALID = _TotalRecordsRow.Substring(160, 10);
                                    _TransactionID = _TotalRecordsRow.Substring(293, 19);
                                    _Routing = _TotalRecordsRow.Substring(448, 30);
                                    _FeeLevel = _TotalRecordsRow.Substring(489, _TotalRecordsRow.Length - 489);
                                    amount = Convert.ToDouble(_TransactionAmount.Trim()) - 0;

                                    _Cardnumber = _TotalRecordsRow.Substring(20, 16);
                                    try
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();

                                    }
                                    catch
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                    }

                                    if (_Cardnumber != "")
                                    {
                                        ECardNumber = AesEncryption.EncryptString(_Cardnumber);
                                    }

                                    if (_Cardnumber != "")
                                    {
                                        _Cardnumber = _Cardnumber.Substring(0, 6) + "XXXXXXXXXXXXXXX".Substring(1, _Cardnumber.Length - 10) + _Cardnumber.Substring(_Cardnumber.Length - 4, 4);
                                    }


                                    _DataTable.Rows.Add(ClientID, ChannelID, ModeID, TimeStamp1, _Cardnumber.Trim(), _referenceNumber.Trim(), _TraceNumber.Trim(), _TerminalOrIssuerId.Trim(), _TranType.Trim(), _ProcessingCode.Trim(), _EntMode.Trim(), _CNSTP.Trim(), _RespCode.Trim(), (_TransactionAmount.Replace(",", string.Empty)), _SettelmentAmount, _DrCrType, _TERMINALID.Trim(), _TransactionID.Trim(), _Routing.Trim(), amount, _Stan, FileName, path, FileDate1, CreatedDt, "", UserName, "", "", "", "", "", "", ECardNumber, IssuingNetwork, CardScheme);
                                    j = EndIndex;
                                }

                            }
                            catch
                            {
                                j = EndIndex;
                            }
                        }
                    }
                }

                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    TotalCount = LineNo;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);

            }


            //(LineNo - _DataTable.Rows.Count );
            return _DataTable;

        }

        public static int GetIndex(string[] aryLines, int StartIndex, string searchStr)
        {
            int idx = -1;
            try
            {
                if (aryLines != null && aryLines.Length > 0)
                {
                    bool found = false;
                    for (idx = StartIndex; idx < aryLines.Length; idx++)
                    {
                        if (aryLines[idx].Contains(searchStr))
                        {
                            found = true;
                            break;
                        }
                    }
                    if (!found)
                        idx = -1;
                }
            }
            catch { }
            return idx;
        }

        public DataTable SplitterEP745(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTime CreatedDt = DateTime.Now;
            string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh:mm:ss tt");

            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("ClientID", typeof(int));
            _DataTable.Columns.Add("ChannelID", typeof(int));
            _DataTable.Columns.Add("ModeID", typeof(int));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("ReferenceNumber", typeof(string));
            _DataTable.Columns.Add("TxnsDateTime", typeof(DateTime));
            _DataTable.Columns.Add("CardNumber", typeof(string));
            _DataTable.Columns.Add("CardType", typeof(string));
            _DataTable.Columns.Add("TxnsStatus", typeof(string));
            _DataTable.Columns.Add("TxnsType", typeof(string));
            _DataTable.Columns.Add("TxnsSubType", typeof(string));
            _DataTable.Columns.Add("TxnsEntryType", typeof(string));
            _DataTable.Columns.Add("TxnsNumber", typeof(string));
            _DataTable.Columns.Add("TxnsAmount", typeof(string));
            _DataTable.Columns.Add("SettlementAmount", typeof(string));
            _DataTable.Columns.Add("TxnsPerticulars", typeof(string));
            _DataTable.Columns.Add("ProcessingCode", typeof(string));
            _DataTable.Columns.Add("ResponseCode", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));

            _DataTable.Columns.Add("BATNUM", typeof(string));
            _DataTable.Columns.Add("ENTMODE", typeof(string));
            _DataTable.Columns.Add("REASCODE", typeof(string));
            _DataTable.Columns.Add("CNSTP", typeof(string));
            _DataTable.Columns.Add("TraceNo", typeof(string));
            _DataTable.Columns.Add("IssuerId", typeof(string));
            _DataTable.Columns.Add("TerminalName", typeof(string));
            _DataTable.Columns.Add("CAID", typeof(string));
            _DataTable.Columns.Add("FPI", typeof(string));
            _DataTable.Columns.Add("CDSQ", typeof(string));
            _DataTable.Columns.Add("ATC", typeof(string));
            _DataTable.Columns.Add("CI", typeof(string));
            _DataTable.Columns.Add("TRID", typeof(string));
            _DataTable.Columns.Add("ACI", typeof(string));
            _DataTable.Columns.Add("TSN", typeof(string));
            _DataTable.Columns.Add("FeeJuris", typeof(string));
            _DataTable.Columns.Add("Routing", typeof(string));
            _DataTable.Columns.Add("FeeLevel", typeof(string));
            _DataTable.Columns.Add("NetworkFee", typeof(string));
            _DataTable.Columns.Add("SourceCurrencyCode", typeof(string));
            _DataTable.Columns.Add("DestinationCurrencyCode", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));
            _DataTable.Columns.Add("IssuingNetwork", typeof(string));
            _DataTable.Columns.Add("CardScheme", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(DateTime));
            _DataTable.Columns.Add("CreatedBy", typeof(string));



            int LineNo = 0;

            try
            {
                int _TotalRows = 0, i = 0, _RecordID = 0;

                i = 0;
                _TotalRows = 0;
                string[] LogFile = File.ReadAllLines(path, Encoding.Default);
                TotalCount = LogFile.Length;

                _TotalRows = LogFile.Length;
                string year = string.Empty;
                DateTime FileDate1 = DateTime.ParseExact(LogFile[4].ToString().Substring(LogFile[4].Length - 8, 7), "ddMMMyy", CultureInfo.InvariantCulture);
                string FileDate = FileDate1.Day.ToString() + "-" + FileDate1.ToString("MMM") + "-" + FileDate1.ToString("yy") + FileDate1.ToString(" hh:mm:ss tt");

                year = "20" + LogFile[4].ToString().Substring(LogFile[4].Length - 3, 2);
                int StartIndex = -1;
                int EndIndex = -1;

                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
                int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());
                int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());
                string StartBlock = dt.Rows[0]["StartIndex"].ToString();
                string EndBlock = dt.Rows[0]["EndIndex"].ToString();

                string CardScheme = "VISA";
                string IssuingNetwork = "VISA";
                string ECardNumber = string.Empty;

                string _TotalRecordsRow = string.Empty;
                string _TotalRecordsLastRow = string.Empty;
                string _TotalRecordsFourthRow = string.Empty;
                string _TotalRecordsThirdRow = string.Empty;
                string _TotalRecordsSecondRow = string.Empty;

                string _TR_TIMESTAMP = string.Empty;
                string _Cardnumber = string.Empty;
                string _referenceNumber = string.Empty;
                string _TraceNumber = string.Empty;
                string _TerminalOrIssuerId = string.Empty;
                string _TranType = string.Empty;
                string _ProcessingCode = string.Empty;
                string _EntMode = string.Empty;
                string _CNSTP = string.Empty;
                string _RespCode = string.Empty;
                string _TransactionAmount = string.Empty;
                string _SettelmentAmount = string.Empty;
                string _TERMINALID = string.Empty;
                string _TerminalName = string.Empty;
                string _TransactionID = string.Empty;
                string strAmount = string.Empty;
                string _ActualAmmt = string.Empty;
                string _BATNUM = string.Empty;
                double mainamount;
                double amount;
                double stramnt;
                double ActualAmmt3;
                string _Stan = string.Empty;
                string _DrCrType = string.Empty;
                string TIME = string.Empty;
                string TDATE = string.Empty;
                string month = string.Empty;
                string TimeStamp = string.Empty;
                string amt = string.Empty;


                string CAID = string.Empty;
                string FPI = string.Empty;
                string CDSQ = string.Empty;
                string ATC = string.Empty;
                string CI = string.Empty;
                string TRID = string.Empty;
                string TSN = string.Empty;
                string ACI = string.Empty;
                string VC = string.Empty;

                string TxnsSubType = string.Empty;
                string TxnsEntryType = string.Empty;
                string TxnsStatus = string.Empty;
                string TxnsPerticulars = string.Empty;
                string CardType = "VISA";

                string FeeJuris = string.Empty;
                string Routing = string.Empty;
                string FeeLevel = string.Empty;
                string NetworkFee = string.Empty;
                string SourceCurrencyCode = string.Empty;
                string DestinationCurrencyCode = string.Empty;

                

                
                
                
                

                string[] ResponseCode1Array = dt.Rows[0]["ResponseCode1"].ToString().Split(new string[] { "," }, StringSplitOptions.None);

                for (int j = 0; j < TotalCount; j++)
                {

                    StartIndex = GetIndex(LogFile, j, StartBlock);
                    EndIndex = GetIndex(LogFile, StartIndex, EndBlock);

                    if (StartIndex == -1)
                    {
                        break;
                    }


                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {
                                if (int.TryParse(LogFile[k].Substring(2, 2), out _RecordID))
                                {

                                    _TotalRecordsRow = string.Empty;
                                    _TotalRecordsLastRow = string.Empty;
                                    _TotalRecordsFourthRow = string.Empty;
                                    _TotalRecordsThirdRow = string.Empty;
                                    _TotalRecordsSecondRow = string.Empty;

                                    _TR_TIMESTAMP = string.Empty;
                                    _Cardnumber = string.Empty;
                                    _referenceNumber = string.Empty;
                                    _TraceNumber = string.Empty;
                                    _TerminalOrIssuerId = string.Empty;
                                    _TranType = string.Empty;
                                    _ProcessingCode = string.Empty;
                                    _EntMode = string.Empty;
                                    _CNSTP = string.Empty;
                                    _RespCode = string.Empty;
                                    _TransactionAmount = string.Empty;
                                    _SettelmentAmount = string.Empty;
                                    _TERMINALID = string.Empty;
                                    _TerminalName = string.Empty;
                                    _TransactionID = string.Empty;
                                    strAmount = string.Empty;
                                    _ActualAmmt = string.Empty;
                                    mainamount = 0; ;
                                    amount = 0;
                                    _Stan = string.Empty;
                                    _DrCrType = string.Empty;


                                    CAID = string.Empty;
                                    FPI = string.Empty;
                                    CDSQ = string.Empty;
                                    ATC = string.Empty;
                                    CI = string.Empty;
                                    TRID = string.Empty;
                                    TSN = string.Empty;
                                    ACI = string.Empty;
                                    VC = string.Empty;

                                    FeeJuris = string.Empty;
                                    Routing = string.Empty;
                                    FeeLevel = string.Empty;
                                    NetworkFee = string.Empty;
                                    SourceCurrencyCode = string.Empty;
                                    DestinationCurrencyCode = string.Empty;

                                    TxnsStatus = string.Empty;
                                    TxnsSubType = string.Empty;
                                    TxnsEntryType = "auto";
                                    TxnsPerticulars = string.Empty;

                                    LineNo++;



                                    _TotalRecordsRow = LogFile[k];
                                    _BATNUM = _TotalRecordsRow.Substring(1, 4);
                                    _TR_TIMESTAMP = _TotalRecordsRow.Substring(5, 5);
                                    TIME = _TotalRecordsRow.Substring(10, 9);
                                    TDATE = _TR_TIMESTAMP.Substring(0, 2);
                                    month = _TR_TIMESTAMP.Substring(2, 3).ToString();
                                    _TR_TIMESTAMP = TDATE + '-' + month + "-" + year + TIME;
                                    DateTime TimeStamp1 = DateTime.ParseExact(_TR_TIMESTAMP, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);
                                    TimeStamp = TimeStamp1.Day.ToString() + "-" + TimeStamp1.ToString("MMM") + "-" + TimeStamp1.ToString("yy") + TimeStamp1.ToString(" hh:mm:ss tt");
                                    _Cardnumber = _TotalRecordsRow.Substring(20, 20);
                                    _referenceNumber = _TotalRecordsRow.Substring(40, 13).Trim();
                                    _Stan = _referenceNumber.Substring(_referenceNumber.Length - 6, 6);
                                    _TraceNumber = _TotalRecordsRow.Substring(53, 7);
                                    _TerminalOrIssuerId = _TotalRecordsRow.Substring(60, 8);
                                    _TranType = _TotalRecordsRow.Substring(72, 5);
                                    _ProcessingCode = _TotalRecordsRow.Substring(77, 7);
                                    _EntMode = _TotalRecordsRow.Substring(84, 9);
                                    _CNSTP = _TotalRecordsRow.Substring(93, 4);
                                    _RespCode = _TotalRecordsRow.Substring(97, 7).Trim();
                                    mainamount = double.Parse(_TotalRecordsRow.Substring(103, 10));
                                    _TransactionAmount = Convert.ToString(mainamount);
                                    _SettelmentAmount = _TotalRecordsRow.Substring(120, 13).Trim().Replace(",", string.Empty);

                                    if (_TotalRecordsRow.Substring(_TotalRecordsRow.Length - 5).Contains("CR"))
                                    {
                                        _DrCrType = "CR";
                                    }
                                    else if (_TotalRecordsRow.Substring(_TotalRecordsRow.Length - 5).Contains("DR"))
                                    {
                                        _DrCrType = "DR";
                                    }

                                    _SettelmentAmount = _SettelmentAmount.Substring(0, _SettelmentAmount.Length - 2);

                                    if (_SettelmentAmount == "0.")
                                    {
                                        _SettelmentAmount = "0.00";
                                    }

                                    DestinationCurrencyCode = _TotalRecordsRow.Substring(113, 5);

                                    stramnt = mainamount % 100;
                                    amt = _TransactionAmount.Trim();
                                    ActualAmmt3 = Convert.ToDouble(amt);
                                    amount = ActualAmmt3 - 0;

                                    _TotalRecordsSecondRow = LogFile[k + 1];

                                    CAID = _TotalRecordsSecondRow.Substring(_TotalRecordsSecondRow.IndexOf("CA ID:") + 6, 10);
                                    _TerminalName = _TotalRecordsSecondRow.Substring(_TotalRecordsSecondRow.IndexOf("CA ID:") + 16, 75);
                                    FPI = _TotalRecordsSecondRow.Substring(_TotalRecordsSecondRow.IndexOf("FPI:") + 4, 10);
                                    _TERMINALID = _TotalRecordsSecondRow.Substring(59, 3);

                                    _TotalRecordsThirdRow = LogFile[k + 2];

                                    CDSQ = _TotalRecordsThirdRow.Substring(_TotalRecordsThirdRow.IndexOf("CD SQ:") + 6, 35);
                                    ATC = _TotalRecordsThirdRow.Substring(_TotalRecordsThirdRow.IndexOf("ATC:") + 4, 10);
                                    TSN = _TotalRecordsThirdRow.Substring(_TotalRecordsThirdRow.IndexOf("TSN:") + 4, 9);
                                    CI = _TotalRecordsThirdRow.Substring(_TotalRecordsThirdRow.IndexOf("CI:") + 3, 10);


                                    _TotalRecordsFourthRow = LogFile[k + 3];
                                    TRID = _TotalRecordsFourthRow.Substring(_TotalRecordsFourthRow.IndexOf("TR ID:") + 6, 20);
                                    ACI = _TotalRecordsFourthRow.Substring(_TotalRecordsFourthRow.IndexOf("ACI:") + 4, 3);
                                    VC = _TotalRecordsFourthRow.Substring(_TotalRecordsFourthRow.IndexOf("VC:") + 3, 10);


                                    _TotalRecordsLastRow = LogFile[k + 4];

                                    FeeJuris = _TotalRecordsLastRow.Substring(_TotalRecordsLastRow.IndexOf("FEE JURIS:") + 10, (_TotalRecordsLastRow.IndexOf("ROUTING:") - _TotalRecordsLastRow.IndexOf("FEE JURIS:") - 10));
                                    Routing = _TotalRecordsLastRow.Substring(_TotalRecordsLastRow.IndexOf("ROUTING:") + 8, (_TotalRecordsLastRow.IndexOf("FEE LEVEL:") - _TotalRecordsLastRow.IndexOf("ROUTING:") - 8));
                                    FeeLevel = _TotalRecordsLastRow.Substring(_TotalRecordsLastRow.IndexOf("FEE LEVEL:") + 10, 30);
                                    NetworkFee = _TotalRecordsLastRow.Substring(_TotalRecordsLastRow.Length - 12);


                                    if (_RespCode == "0" || _RespCode == "00")
                                    {
                                        TxnsStatus = "Sucessfull";
                                    }
                                    else
                                    {
                                        TxnsStatus = "Unsucessfull";
                                    }

                                    TxnsPerticulars = FeeJuris.Trim() + Routing.Trim() + FeeLevel.Trim() + NetworkFee.Trim();

                                    SourceCurrencyCode = "USD";



                                    try
                                    {
                                        _Cardnumber = _TotalRecordsRow.Substring(20, 16);
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                    }
                                    catch
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                    }

                                    if (_Cardnumber != "")
                                    {
                                        ECardNumber = AesEncryption.EncryptString(_Cardnumber);
                                    }

                                    if (_Cardnumber != "")
                                    {
                                        _Cardnumber = _Cardnumber.Substring(0, 6) + "XXXXXXXXXXXXXXX".Substring(1, _Cardnumber.Length - 10) + _Cardnumber.Substring(_Cardnumber.Length - 4, 4);
                                    }

                                    _DataTable.Rows.Add(ClientCode, ChannelID, ModeID, _TERMINALID.Trim(), _referenceNumber.Trim(), TimeStamp, _Cardnumber.Trim(), CardType, TxnsStatus, _TranType.Trim(), TxnsSubType.Trim(), TxnsEntryType.Trim(), TRID.Trim(), amount, _SettelmentAmount.Trim(), TxnsPerticulars.Trim(), _ProcessingCode.Trim(), _RespCode.Trim(), _DrCrType.Trim(), _BATNUM.Trim(), _EntMode.Trim(), _RespCode.Trim(), _CNSTP.Trim(), _TraceNumber.Trim(), _TerminalOrIssuerId.Trim(), _TerminalName.Trim(), CAID.Trim(), FPI.Trim(), CDSQ.Trim(), ATC.Trim(), CI.Trim(), TRID.Trim(), ACI.Trim(), TSN.Trim(), FeeJuris.Trim(), Routing.Trim(), FeeLevel.Trim(), NetworkFee.Trim(), SourceCurrencyCode.Trim(), DestinationCurrencyCode.Trim(), null, null, null, null, ECardNumber, IssuingNetwork, CardScheme, FileName, path, FileDate, UserName);

                                    j = EndIndex;
                                }

                            }
                            catch (Exception ex)
                            {
                                j = EndIndex;
                            }
                        }
                    }
                }

                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    TotalCount = _DataTable.Rows.Count;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }


            //(LineNo - _DataTable.Rows.Count );
            return _DataTable;

        }

        public DataTable SplitterATMACQUIRERCHBK(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTime CreatedDt = DateTime.Now;
            string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh:mm:ss tt");

            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(string));
            _DataTable.Columns.Add("CARDNO", typeof(string));
            _DataTable.Columns.Add("REFNO", typeof(string));
            _DataTable.Columns.Add("TRACENO", typeof(string));
            _DataTable.Columns.Add("TERMINALISSUERID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("PROCESSINGCODE", typeof(string));
            _DataTable.Columns.Add("ENTMODE", typeof(string));
            _DataTable.Columns.Add("CNSTP", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("TAMOUNT", typeof(string));
            _DataTable.Columns.Add("SAMOUNT", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONID", typeof(string));
            _DataTable.Columns.Add("ROUTING", typeof(string));
            _DataTable.Columns.Add("ACTUALAMOUNT", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("COMPLAINTID", typeof(string));
            _DataTable.Columns.Add("CLAIMDATE", typeof(string));
            _DataTable.Columns.Add("APPROVALCODE", typeof(string));
            _DataTable.Columns.Add("CLAIMTYPE", typeof(string));
            _DataTable.Columns.Add("CycleID", typeof(string));
            _DataTable.Columns.Add("CycleDate", typeof(string));
            _DataTable.Columns.Add("CURRENCYCODE", typeof(string));
            _DataTable.Columns.Add("ECardNumber", typeof(string));

            int LineNo = 0;
            int ErrorLine = 0;
            try
            {
                int _TotalRows = 0, i = 0, _Rownumber = 0;
                int _RecordID = 0;
                i = 0;
                _TotalRows = 0;
                string[] LogFile = File.ReadAllLines(path, Encoding.Default);
                TotalCount = LogFile.Length;

                _TotalRows = LogFile.Length;
                string year = string.Empty;
                DateTime FileDate1 = DateTime.ParseExact(LogFile[4].ToString().Substring(LogFile[4].Length - 8, 7), "ddMMMyy", CultureInfo.InvariantCulture);
                string FileDate = FileDate1.Day.ToString() + "-" + FileDate1.ToString("MMM") + "-" + FileDate1.ToString("yy") + FileDate1.ToString(" hh:mm:ss tt");

                year = "20" + LogFile[4].ToString().Substring(LogFile[4].Length - 3, 2);
                int StartIndex = -1;
                int EndIndex = -1;

                string _TotalRecordsRow = string.Empty;
                string _TR_TIMESTAMP = string.Empty;
                string _Cardnumber = string.Empty;
                string _referenceNumber = string.Empty;
                string _TraceNumber = string.Empty;
                string _TerminalOrIssuerId = string.Empty;
                string _TranType = string.Empty;
                string _ProcessingCode = string.Empty;
                string _EntMode = string.Empty;
                string _CNSTP = string.Empty;
                string _RespCode = string.Empty;
                string _TransactionAmount = string.Empty;
                string _SettelmentAmount = string.Empty;
                string _TERMINALID = string.Empty;
                string APPROVALCODE = string.Empty;
                string _TransactionID = string.Empty;
                string strAmount = string.Empty;
                string _Routing = string.Empty;
                string _FeeLevel = string.Empty;
                string _ActualAmmt = string.Empty;
                double mainamount;
                double amount;
                string _Stan = string.Empty;
                string _DrCrType = string.Empty;
                string COMPLAINTID = string.Empty;
                string _ClaimType = string.Empty;
                string _CycleID = string.Empty;
                string _CycleDate = string.Empty;
                string _CycleDateNew = string.Empty;
                string CurrencyCode = string.Empty;
                string TIME_CycleDate = string.Empty;
                string TDATE_CycleDate = string.Empty;
                string month_CycleDate = string.Empty;
                string TIME = string.Empty;
                string TDATE = string.Empty;
                string month = string.Empty;
                string TimeStamp = string.Empty;
                double stramnt = 0;
                double ActualAmmt3 = 0;
                string RRN = string.Empty;
                string strComplaintID = string.Empty;
                string ECardNumber = string.Empty;

                int ClientID = int.Parse(dt.Rows[0]["ClientID"].ToString());
                int ModeID = int.Parse(dt.Rows[0]["ModeID"].ToString());
                int ChannelID = int.Parse(dt.Rows[0]["ChannelID"].ToString());

                Random generator = new Random();

                

                
                
                
                

                for (int j = 0; j < TotalCount; j++)
                {

                    StartIndex = GetIndex(LogFile, j, "SMS601C");
                    EndIndex = GetIndex(LogFile, StartIndex, "SMS601I");

                    if (StartIndex == -1)
                    {
                        break;
                    }


                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {
                                if (int.TryParse(LogFile[k].Substring(2, 2), out _RecordID))
                                {
                                    _TotalRecordsRow = string.Empty;
                                    _TR_TIMESTAMP = string.Empty;
                                    _Cardnumber = string.Empty;
                                    _referenceNumber = string.Empty;
                                    _TraceNumber = string.Empty;
                                    _TerminalOrIssuerId = string.Empty;
                                    _TranType = string.Empty;
                                    _ProcessingCode = string.Empty;
                                    _EntMode = string.Empty;
                                    _CNSTP = string.Empty;
                                    _RespCode = string.Empty;
                                    _TransactionAmount = string.Empty;
                                    _SettelmentAmount = string.Empty;
                                    _TERMINALID = string.Empty;
                                    APPROVALCODE = string.Empty;
                                    _TransactionID = string.Empty;
                                    strAmount = string.Empty;
                                    _Routing = string.Empty;
                                    _FeeLevel = string.Empty;
                                    _ActualAmmt = string.Empty;
                                    mainamount = 0;
                                    amount = 0;
                                    _Stan = string.Empty;
                                    _DrCrType = string.Empty;
                                    COMPLAINTID = string.Empty;
                                    _ClaimType = string.Empty;
                                    _CycleID = string.Empty;
                                    _CycleDate = string.Empty;
                                    _CycleDateNew = string.Empty;
                                    CurrencyCode = string.Empty;

                                    TIME_CycleDate = string.Empty;
                                    TDATE_CycleDate = string.Empty;
                                    month_CycleDate = string.Empty;

                                    LineNo++;
                                    _TotalRecordsRow = LogFile[k] + LogFile[k + 1] + LogFile[k + 2] + LogFile[k + 3] + LogFile[k + 4];
                                    if (_TotalRecordsRow.Contains("FEE LEVEL: DISP FIN") || _TotalRecordsRow.Contains("FEE LEVEL: DISP RESP FIN"))
                                    {
                                        _TR_TIMESTAMP = _TotalRecordsRow.Substring(5, 5);
                                        TIME = _TotalRecordsRow.Substring(10, 9);
                                        TDATE = _TR_TIMESTAMP.Substring(0, 2);
                                        month = _TR_TIMESTAMP.Substring(2, 3).ToString();
                                        _TR_TIMESTAMP = TDATE + '-' + month + "-" + year + TIME;
                                        DateTime TimeStamp1 = DateTime.ParseExact(_TR_TIMESTAMP, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                                        if (TimeStamp1.Month > FileDate1.Month)
                                        {
                                            TimeStamp1 = TimeStamp1.AddYears(-1);
                                        }

                                        TimeStamp = TimeStamp1.Day.ToString() + "-" + TimeStamp1.ToString("MMM") + "-" + TimeStamp1.ToString("yy") + TimeStamp1.ToString(" hh:mm:ss tt");


                                        if (_TotalRecordsRow.Contains("FEE LEVEL: DISP FIN"))
                                        {
                                            _CycleID = "1";
                                            _ClaimType = "Full";

                                        }

                                        if (_TotalRecordsRow.Contains("FEE LEVEL: DISP RESP FIN"))
                                        {
                                            _CycleID = "2";
                                            _ClaimType = "Full";

                                            _CycleDateNew = TimeStamp;
                                            _CycleDate = _TotalRecordsRow.Substring(138, 5);
                                            TIME_CycleDate = _TotalRecordsRow.Substring(144, 8);
                                            TDATE_CycleDate = _CycleDate.Substring(0, 2);
                                            month_CycleDate = _CycleDate.Substring(2, 3).ToString();
                                            _CycleDate = TDATE_CycleDate + '-' + month_CycleDate + "-" + year + " " + TIME_CycleDate;
                                            DateTime TimeStamp1_CycleDate = DateTime.ParseExact(_CycleDate, "dd-MMM-yyyy HH:mm:ss", CultureInfo.InvariantCulture);

                                            if (TimeStamp1_CycleDate.Month > FileDate1.Month)
                                            {

                                                TimeStamp1_CycleDate = TimeStamp1_CycleDate.AddYears(-1);

                                            }

                                            _CycleDate = TimeStamp1_CycleDate.Day.ToString() + "-" + TimeStamp1_CycleDate.ToString("MMM") + "-" + TimeStamp1_CycleDate.ToString("yy") + TimeStamp1_CycleDate.ToString(" hh:mm:ss tt");

                                            TimeStamp = _CycleDate;


                                        }


                                        _Cardnumber = _TotalRecordsRow.Substring(20, 20);
                                        RRN = _TotalRecordsRow.Substring(40, 13).Trim();
                                        _referenceNumber = RRN.Substring(RRN.Length - 6, 6);
                                        _Stan = _referenceNumber.Substring(_referenceNumber.Length - 6, 6);
                                        _TraceNumber = _TotalRecordsRow.Substring(53, 7);
                                        APPROVALCODE = _TotalRecordsRow.Substring(53, 7);
                                        _TerminalOrIssuerId = _TotalRecordsRow.Substring(60, 8);
                                        _TranType = _TotalRecordsRow.Substring(72, 5);
                                        _ProcessingCode = _TotalRecordsRow.Substring(77, 7);
                                        _EntMode = _TotalRecordsRow.Substring(84, 9);
                                        _CNSTP = _TotalRecordsRow.Substring(93, 4);
                                        _RespCode = _TotalRecordsRow.Substring(97, 7);
                                        mainamount = double.Parse(_TotalRecordsRow.Substring(104, 9));
                                        _TransactionAmount = Convert.ToString(mainamount);
                                        _SettelmentAmount = _TotalRecordsRow.Substring(120, 29).Trim().Replace(",", string.Empty);

                                        _DrCrType = _SettelmentAmount.Substring(_SettelmentAmount.Length - 2);
                                        _SettelmentAmount = _SettelmentAmount.Substring(0, _SettelmentAmount.Length - 2);

                                        CurrencyCode = _TotalRecordsRow.Substring(114, 3).Trim().ToString();

                                        if (_SettelmentAmount == "0.")
                                        {
                                            _SettelmentAmount = "0.00";
                                        }
                                        _TERMINALID = _TotalRecordsRow.Substring(160, 10);
                                        _TransactionID = _TotalRecordsRow.Substring(293, 19);
                                        _Routing = _TotalRecordsRow.Substring(448, 30);
                                        _FeeLevel = _TotalRecordsRow.Substring(489, _TotalRecordsRow.Length - 489);
                                        stramnt = mainamount % 100;
                                        ActualAmmt3 = Convert.ToDouble(_TransactionAmount.Trim());
                                        amount = ActualAmmt3 - 0;

                                        strComplaintID = generator.Next(100000, 999999).ToString("D6");
                                        COMPLAINTID = strComplaintID + _referenceNumber.Substring(_referenceNumber.Length - 4).ToString();

                                        try
                                        {
                                            _Cardnumber = _TotalRecordsRow.Substring(20, 16);
                                            _Cardnumber = _Cardnumber.ToString().Trim();
                                        }
                                        catch
                                        {
                                            _Cardnumber = _Cardnumber.ToString().Trim();
                                        }

                                        if (_Cardnumber != "")
                                        {
                                            ECardNumber = AesEncryption.EncryptString(_Cardnumber);
                                        }

                                        if (_Cardnumber != "")
                                        {
                                            _Cardnumber = _Cardnumber.Substring(0, 6) + "XXXXXXXXXXXXXXX".Substring(1, _Cardnumber.Length - 10) + _Cardnumber.Substring(_Cardnumber.Length - 4, 4);
                                        }


                                        _DataTable.Rows.Add(TimeStamp, _Cardnumber.Trim(), _referenceNumber.Trim(), _TraceNumber.Trim(), _TerminalOrIssuerId.Trim(), _TranType.Trim(), _ProcessingCode.Trim(), _EntMode.Trim(), _CNSTP.Trim(), _RespCode.Trim(), (_TransactionAmount.Replace(",", string.Empty)), _SettelmentAmount, _DrCrType, _TERMINALID.Trim(), _TransactionID.Trim(), _Routing.Trim(), amount, _Stan, FileName, path, FileDate, CreatedDate, "", UserName, "", "", "", "", "", "", COMPLAINTID, FileDate, APPROVALCODE, _ClaimType, _CycleID, _CycleDateNew, CurrencyCode, ECardNumber);

                                        j = EndIndex;
                                    }
                                }

                            }
                            catch (Exception ex)
                            {
                                j = EndIndex;
                                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }
                        }
                    }
                }

                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    TotalCount = _DataTable.Rows.Count;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }


            //(LineNo - _DataTable.Rows.Count );
            return _DataTable;

        }

        public DataTable SplitterPOSACQUIRERCHBK(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTime CreatedDt = DateTime.Now;
            string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh:mm:ss tt");

            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();

            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(string));
            _DataTable.Columns.Add("CARDNO", typeof(string));
            _DataTable.Columns.Add("REFNO", typeof(string));
            _DataTable.Columns.Add("TRACENO", typeof(string));
            _DataTable.Columns.Add("TERMINALISSUERID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("PROCESSINGCODE", typeof(string));
            _DataTable.Columns.Add("ENTMODE", typeof(string));
            _DataTable.Columns.Add("CNSTP", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("TAMOUNT", typeof(string));
            _DataTable.Columns.Add("SAMOUNT", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONID", typeof(string));
            _DataTable.Columns.Add("ROUTING", typeof(string));
            _DataTable.Columns.Add("ACTUALAMOUNT", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("COMPLAINTID", typeof(string));
            _DataTable.Columns.Add("CLAIMDATE", typeof(string));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));

            int LineNo = 0;
            try
            {
                int _TotalRows = 0, i = 0;
                _TotalRows = 0;
                string[] LogFile = File.ReadAllLines(path, Encoding.Default);
                TotalCount = LogFile.Length;

                _TotalRows = LogFile.Length;
                string year = string.Empty;
                DateTime FileDate1 = DateTime.ParseExact(LogFile[1].ToString().Substring(LogFile[1].Length - 8, 8), "dd/MM/yy", CultureInfo.InvariantCulture);

                year = "20" + LogFile[1].ToString().Substring(LogFile[1].Length - 2, 2);
                int StartIndex = -1;
                int EndIndex = -1;
                string CHANNELID = string.Empty;
                string MODEID = string.Empty;

                string _TotalRecordsRow = string.Empty;
                string _TR_TIMESTAMP = string.Empty;
                string _Cardnumber = string.Empty;
                string _referenceNumber = string.Empty;
                string _TraceNumber = string.Empty;
                string _TerminalOrIssuerId = string.Empty;
                string _TranType = string.Empty;
                string _ProcessingCode = string.Empty;
                string _EntMode = string.Empty;
                string _CNSTP = string.Empty;
                string _RespCode = string.Empty;
                string _TransactionAmount = string.Empty;
                string _SettelmentAmount = string.Empty;
                string _TERMINALID = string.Empty;
                string _TransactionID = string.Empty;
                string strAmount = string.Empty;
                string _Routing = string.Empty;
                string _FeeLevel = string.Empty;
                string _ActualAmmt = string.Empty;
                double mainamount;

                double stramnt;
                string _Stan = string.Empty;
                string _DrCrType = string.Empty;
                string COMPLAINTID = string.Empty;
                DateTime? TimeStamp1 = null;
                string Year = string.Empty;
                string Month = string.Empty;
                string Date = string.Empty;
                string ReserveField1 = string.Empty;
                string ReserveField2 = string.Empty;
                string CurrencyCode = string.Empty;
                DateTime? ClaimDate = null;


                for (int j = 0; j < TotalCount; j++)
                {

                    StartIndex = GetIndex(LogFile, j, "Chargeback, Sales Draft - First - VCR");
                    EndIndex = GetIndex(LogFile, StartIndex, "Surcharge Credit/Dbt Ind");

                    if (StartIndex == -1)
                    {
                        break;
                    }


                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        _TotalRecordsRow = string.Empty;
                        _TR_TIMESTAMP = string.Empty;
                        _Cardnumber = string.Empty;
                        _referenceNumber = string.Empty;
                        _TraceNumber = string.Empty;
                        _TerminalOrIssuerId = string.Empty;
                        _TranType = string.Empty;
                        _ProcessingCode = string.Empty;
                        _EntMode = string.Empty;
                        _CNSTP = string.Empty;
                        _RespCode = string.Empty;
                        _TransactionAmount = string.Empty;
                        _SettelmentAmount = string.Empty;
                        _TERMINALID = string.Empty;
                        _TransactionID = string.Empty;
                        strAmount = string.Empty;
                        _Routing = string.Empty;
                        _FeeLevel = string.Empty;
                        _ActualAmmt = string.Empty;
                        _Stan = string.Empty;
                        _DrCrType = string.Empty;
                        COMPLAINTID = string.Empty;
                        TimeStamp1 = null;
                        Year = string.Empty;
                        Month = string.Empty;
                        Date = string.Empty;
                        ReserveField1 = string.Empty;
                        ReserveField2 = string.Empty;
                        CurrencyCode = string.Empty;
                        ClaimDate = null;


                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {

                                _TotalRecordsRow = LogFile[k];
                                if (_TotalRecordsRow.Contains("Purchase Date"))
                                {
                                    _TR_TIMESTAMP = _TotalRecordsRow.Substring(27, 8);
                                    Year = _TotalRecordsRow.Substring(27, 4);
                                    Month = _TR_TIMESTAMP.Substring(4, 2);
                                    Date = _TR_TIMESTAMP.Substring(6, 2).ToString();
                                    _TR_TIMESTAMP = Date + '-' + Month + "-" + Year;
                                    TimeStamp1 = DateTime.ParseExact(_TR_TIMESTAMP, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                                }

                                if (_TotalRecordsRow.Contains("Acct Number & Extension"))
                                {
                                    _Cardnumber = _TotalRecordsRow.Substring(27, 16);
                                }
                                if (_TotalRecordsRow.Contains("Destination Currency Code"))
                                {
                                    int n;
                                    bool isNumeric = int.TryParse(_TotalRecordsRow.Substring(27, 16).ToString(), out n);
                                    if (isNumeric == true)
                                    {

                                        if (!_TotalRecordsRow.Substring(27, 16).ToString().Trim().Contains("50"))
                                        {
                                            CurrencyCode = "0";
                                        }

                                    }

                                }
                                if (_TotalRecordsRow.Contains("Source Amount"))
                                {
                                    mainamount = double.Parse(_TotalRecordsRow.Substring(27, 16));
                                    stramnt = mainamount / 100;
                                    _TransactionAmount = stramnt.ToString(); ;
                                }
                                if (_TotalRecordsRow.Contains("Destination Amount"))
                                {
                                    _SettelmentAmount = _TotalRecordsRow.Substring(27, 16);
                                }

                                if (_TotalRecordsRow.Contains("Surcharge Credit/Dbt Ind"))
                                {
                                    _DrCrType = _TotalRecordsRow.Substring(93, 10).Trim();

                                }

                                if (_TotalRecordsRow.Contains("Acquirer Reference Nbr"))
                                {
                                    _referenceNumber = _TotalRecordsRow.Substring(27, 37).Trim();
                                    _Stan = _referenceNumber.Substring(_referenceNumber.Length - 7, 7);
                                    _TraceNumber = _referenceNumber.Substring(_referenceNumber.Length - 7, 7); ;
                                }
                                if (_TotalRecordsRow.Contains("Authorization Code"))
                                {

                                    _ProcessingCode = _TotalRecordsRow.Substring(93, 7);
                                }
                                if (_TotalRecordsRow.Contains("Terminal ID"))
                                {
                                    _TERMINALID = _TotalRecordsRow.Substring(27, 8).Trim();
                                }

                                if (_TotalRecordsRow.Contains("VROL Case Number"))
                                {
                                    _TransactionID = _TotalRecordsRow.Substring(93, 37).Trim();
                                }

                                if (_TotalRecordsRow.Contains("Chargeback Reason Code"))
                                {
                                    ReserveField1 = _TotalRecordsRow.Substring(93, 5).Trim().ToString();
                                }
                                if (_TotalRecordsRow.Contains("Dispute Condition"))
                                {
                                    ReserveField2 = _TotalRecordsRow.Substring(93, 5).Trim().ToString();
                                }
                                if (_TotalRecordsRow.Contains("Dispute Status"))
                                {
                                    _RespCode = _TotalRecordsRow.Substring(93, 10).Trim().ToString();
                                }

                                if (_TotalRecordsRow.Contains("Central Processing Date"))
                                {
                                    try
                                    {


                                        ClaimDate = DateTime.ParseExact(_TotalRecordsRow.Substring(93, 10).Trim().ToString(), "yyyyMMdd", CultureInfo.InvariantCulture);
                                    }
                                    catch (Exception)
                                    {

                                        ClaimDate = DateTime.Now;
                                    }
                                }


                                if (_TotalRecordsRow.Contains("Acct Number & Extension"))
                                {
                                    _Cardnumber = _TotalRecordsRow.Substring(27, 16);
                                    try
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                        _Cardnumber = _Cardnumber.Substring(0, 6) + "XXXXXXXXXXXXXXX".Substring(1, _Cardnumber.Length - 10) + _Cardnumber.Substring(_Cardnumber.Length - 4, 4);
                                    }
                                    catch
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                j = EndIndex;
                                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
                            }
                        }
                        Random generator = new Random();
                        String strComplaintID = generator.Next(100000, 999999).ToString("D6");
                        COMPLAINTID = strComplaintID + _referenceNumber.Substring(_referenceNumber.Length - 4).ToString();
                        j = EndIndex;
                        _DataTable.Rows.Add(TimeStamp1.ToString(), _Cardnumber.Trim(), _referenceNumber.Trim(), _TraceNumber.Trim(), _TerminalOrIssuerId.Trim(), _TranType.Trim(), _ProcessingCode.Trim(), _EntMode.Trim(), _CNSTP.Trim(), _RespCode.Trim(), (_TransactionAmount.Replace(",", string.Empty)), _SettelmentAmount, _DrCrType, _TERMINALID.Trim(), _TransactionID.Trim(), _Routing.Trim(), _TransactionAmount, _Stan, FileName, path, FileDate1, CreatedDate, "", UserName, "", "", "", "", "", "", COMPLAINTID, ClaimDate, CurrencyCode);
                        LineNo++;
                    }
                }
                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    TotalCount = _DataTable.Rows.Count;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            return _DataTable;

        }

        public DataTable SplitterPOSISSUERCHBK(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTime CreatedDt = DateTime.Now;
            string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh:mm:ss tt");

            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(string));
            _DataTable.Columns.Add("CARDNO", typeof(string));
            _DataTable.Columns.Add("REFNO", typeof(string));
            _DataTable.Columns.Add("TRACENO", typeof(string));
            _DataTable.Columns.Add("TERMINALISSUERID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("PROCESSINGCODE", typeof(string));
            _DataTable.Columns.Add("ENTMODE", typeof(string));
            _DataTable.Columns.Add("CNSTP", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("TAMOUNT", typeof(string));
            _DataTable.Columns.Add("SAMOUNT", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONID", typeof(string));
            _DataTable.Columns.Add("ROUTING", typeof(string));
            _DataTable.Columns.Add("ACTUALAMOUNT", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("COMPLAINTID", typeof(string));
            _DataTable.Columns.Add("CLAIMDATE", typeof(string));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            int LineNo = 0;

            try
            {
                int _TotalRows = 0;

                string[] LogFile = File.ReadAllLines(path, Encoding.Default);
                TotalCount = LogFile.Length;

                _TotalRows = LogFile.Length;
                string year = string.Empty;
                DateTime FileDate1 = DateTime.ParseExact(LogFile[1].ToString().Substring(LogFile[1].Length - 8, 8), "yy/MM/dd", CultureInfo.InvariantCulture);

                int StartIndex = -1;
                int EndIndex = -1;

                string _TotalRecordsRow = string.Empty;
                string _TR_TIMESTAMP = string.Empty;
                string _Cardnumber = string.Empty;
                string _referenceNumber = string.Empty;
                string _TraceNumber = string.Empty;
                string _TerminalOrIssuerId = string.Empty;
                string _TranType = string.Empty;
                string _ProcessingCode = string.Empty;
                string _EntMode = string.Empty;
                string _CNSTP = string.Empty;
                string _RespCode = string.Empty;
                string _TransactionAmount = string.Empty;
                string _SettelmentAmount = string.Empty;
                string _TERMINALID = string.Empty;
                string _TransactionID = string.Empty;
                string strAmount = string.Empty;
                string _Routing = string.Empty;
                string _FeeLevel = string.Empty;
                string _ActualAmmt = string.Empty;
                double mainamount;
                double amount;
                double stramnt;
                string _Stan = string.Empty;
                string _DrCrType = string.Empty;
                string COMPLAINTID = string.Empty;
                DateTime? TimeStamp1 = null;
                string Year = string.Empty;
                string Month = string.Empty;
                string Date = string.Empty;
                string ReserveField1 = string.Empty;
                string ReserveField2 = string.Empty;
                int month = 0;
                string CPDateStr = string.Empty;
                string CurrencyCode = string.Empty;
                string Central_Processing_Date = string.Empty;
                int fyear = 0;
                string FileNameSplit = string.Empty;
                string FileDateString = string.Empty;

                string FileDateStr = string.Empty;
                string FName = Path.GetFileNameWithoutExtension(FileName);
                fyear = Convert.ToInt32(FName.Substring(FName.Length - 2, 2));


                for (int j = 0; j < TotalCount; j++)
                {

                    StartIndex = GetIndex(LogFile, j, "Dispute Financial Status Advice");
                    EndIndex = GetIndex(LogFile, StartIndex, "Rate Table ID");

                    if (StartIndex == -1)
                    {
                        break;
                    }

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        _TotalRecordsRow = string.Empty;
                        _TR_TIMESTAMP = string.Empty;
                        _Cardnumber = string.Empty;
                        _referenceNumber = string.Empty;
                        _TraceNumber = string.Empty;
                        _TerminalOrIssuerId = string.Empty;
                        _TranType = string.Empty;
                        _ProcessingCode = string.Empty;
                        _EntMode = string.Empty;
                        _CNSTP = string.Empty;
                        _RespCode = string.Empty;
                        _TransactionAmount = string.Empty;
                        _SettelmentAmount = string.Empty;
                        _TERMINALID = string.Empty;
                        _TransactionID = string.Empty;
                        strAmount = string.Empty;
                        _Routing = string.Empty;
                        _FeeLevel = string.Empty;
                        _ActualAmmt = string.Empty;
                        _Stan = string.Empty;
                        _DrCrType = string.Empty;
                        COMPLAINTID = string.Empty;
                        TimeStamp1 = null;
                        Year = string.Empty;
                        Month = string.Empty;
                        Date = string.Empty;
                        ReserveField1 = string.Empty;
                        ReserveField2 = string.Empty;
                        month = 0;
                        CPDateStr = string.Empty;
                        CurrencyCode = string.Empty;
                        Central_Processing_Date = string.Empty;
                        fyear = 0;
                        FileNameSplit = string.Empty;
                        FileDateString = string.Empty;
                        FileDateStr = string.Empty;
                        FName = Path.GetFileNameWithoutExtension(FileName);
                        fyear = Convert.ToInt32(FName.Substring(FName.Length - 2, 2));


                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {

                                _TotalRecordsRow = LogFile[k];
                                if (_TotalRecordsRow.Contains("Purchase Date"))
                                {
                                    _TR_TIMESTAMP = _TotalRecordsRow.Substring(27, 8);
                                    Year = _TotalRecordsRow.Substring(27, 4);
                                    Month = _TR_TIMESTAMP.Substring(4, 2);
                                    Date = _TR_TIMESTAMP.Substring(6, 2).ToString();
                                    _TR_TIMESTAMP = Date + '-' + Month + "-" + Year;
                                    TimeStamp1 = DateTime.ParseExact(_TR_TIMESTAMP, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                                }

                                if (_TotalRecordsRow.Contains("Acct Number & Extension"))
                                {
                                    _Cardnumber = _TotalRecordsRow.Substring(27, 16);
                                }
                                if (_TotalRecordsRow.Contains("Source Amount"))
                                {
                                    mainamount = double.Parse(_TotalRecordsRow.Substring(27, 16));
                                    stramnt = mainamount / 100;
                                    _TransactionAmount = stramnt.ToString();
                                }
                                if (_TotalRecordsRow.Contains("Destination Amount"))
                                {
                                    _SettelmentAmount = _TotalRecordsRow.Substring(27, 16);
                                }
                                if (_TotalRecordsRow.Contains("Source Currency Code"))
                                {
                                    int n;
                                    bool isNumeric = int.TryParse(_TotalRecordsRow.Substring(27, 16).ToString().Trim(), out n);
                                    if (isNumeric == true)
                                    {

                                        if (!_TotalRecordsRow.Substring(27, 16).ToString().Trim().Contains("50"))
                                        {
                                            CurrencyCode = "0";
                                        }

                                    }

                                }
                                if (_TotalRecordsRow.Contains("Acquirer Reference Nbr"))
                                {
                                    _referenceNumber = _TotalRecordsRow.Substring(27, 37).Trim();
                                    _Stan = _referenceNumber.Substring(_referenceNumber.Length - 7, 7);
                                    _TraceNumber = _referenceNumber.Substring(_referenceNumber.Length - 7, 7); ;
                                }
                                if (_TotalRecordsRow.Contains("Authorization Code"))
                                {

                                    _ProcessingCode = _TotalRecordsRow.Substring(93, 7);
                                }
                                if (_TotalRecordsRow.Contains("Terminal ID"))
                                {
                                    _TERMINALID = _TotalRecordsRow.Substring(27, 8).Trim();
                                }

                                if (_TotalRecordsRow.Contains("VROL Case Number"))
                                {
                                    _TransactionID = _TotalRecordsRow.Substring(93, 37).Trim();
                                }

                                if (_TotalRecordsRow.Contains("Chargeback Reason Code"))
                                {
                                    ReserveField1 = _TotalRecordsRow.Substring(93, 5).Trim().ToString();
                                }
                                if (_TotalRecordsRow.Contains("Dispute Condition"))
                                {
                                    ReserveField2 = _TotalRecordsRow.Substring(93, 5).Trim().ToString();
                                }
                                if (_TotalRecordsRow.Contains("Dispute Status"))
                                {
                                    _RespCode = _TotalRecordsRow.Substring(27, 10).Trim().ToString();
                                }

                                if (_TotalRecordsRow.Contains("Central Processing Date"))
                                {
                                    Central_Processing_Date = _TotalRecordsRow.Substring(93, 6).Trim();
                                    //ClaimDate = DateTime.ParseExact(_TotalRecordsRow.Substring(93, 10).Trim().ToString(), "yyyyMMdd", CultureInfo.InvariantCulture);
                                    try
                                    {
                                        if (Convert.ToInt32(Central_Processing_Date.Substring(0, 2)) > month)
                                        {
                                            year = (fyear - 1).ToString();
                                        }
                                        else
                                        {
                                            year = fyear.ToString();//DateTime.Now.Year.ToString();
                                        }

                                        int CDate = Convert.ToInt32(Central_Processing_Date);
                                        int CDay = CDate % 1000;
                                        if (CDay == 366)
                                        {
                                            CDay = CDay - 1;
                                        }
                                        int Cyear = fyear;
                                        var CDateTime = new DateTime(Cyear, 1, 1);
                                        var Central_Processing_DateTime = CDateTime.AddDays(CDay - 1);
                                        //CentralProcessDate1 = Central_Processing_DateTime.ToString("yyyy/MM/dd HH:mm:ss");
                                        CPDateStr = Central_Processing_DateTime.Day.ToString() + "-" + Central_Processing_DateTime.ToString("MMM") + "-" + Central_Processing_DateTime.ToString("yy") + Central_Processing_DateTime.ToString(" hh:mm:ss tt");
                                    }
                                    catch
                                    {

                                        CPDateStr = CreatedDate;
                                    }

                                }
                                if (_TotalRecordsRow.Contains("Surcharge Credit/Dbt Ind"))
                                {

                                    _DrCrType = _TotalRecordsRow.Substring(93, 10).Trim();
                                }


                                if (_TotalRecordsRow.Contains("Acct Number & Extension"))
                                {

                                    string dummy = "XXXXXXXXXXXXXXX";
                                    _Cardnumber = _TotalRecordsRow.Substring(27, 16);
                                    try
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                        _Cardnumber = _Cardnumber.Substring(0, 6) + dummy.Substring(1, _Cardnumber.Length - 10) + _Cardnumber.Substring(_Cardnumber.Length - 4, 4);
                                    }
                                    catch
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                j = EndIndex;

                            }
                        }
                        Random generator = new Random();
                        String strComplaintID = generator.Next(100000, 999999).ToString("D6");
                        COMPLAINTID = strComplaintID + _referenceNumber.Substring(_referenceNumber.Length - 4).ToString();
                        j = EndIndex;

                        _DataTable.Rows.Add(TimeStamp1.ToString(), _Cardnumber.Trim(), _referenceNumber.Trim(), _TraceNumber.Trim(), _TerminalOrIssuerId.Trim(), _TranType.Trim(), _ProcessingCode.Trim(), _EntMode.Trim(), _CNSTP.Trim(), _RespCode.Trim(), (_TransactionAmount.Replace(",", string.Empty)), _SettelmentAmount, _DrCrType, _TERMINALID.Trim(), _TransactionID.Trim(), _Routing.Trim(), _TransactionAmount, _Stan, FileName, path, FileDate1, CreatedDate, "", UserName, "", "", "", "", "", "", COMPLAINTID, CPDateStr, CurrencyCode);
                        LineNo++;
                    }
                }

                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    TotalCount = _DataTable.Rows.Count;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            return _DataTable;

        }

        public DataTable SplitterATMISSUERCHBK(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTime CreatedDt = DateTime.Now;
            string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh:mm:ss tt");

            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(string));
            _DataTable.Columns.Add("CARDNO", typeof(string));
            _DataTable.Columns.Add("REFNO", typeof(string));
            _DataTable.Columns.Add("TRACENO", typeof(string));
            _DataTable.Columns.Add("TERMINALISSUERID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("PROCESSINGCODE", typeof(string));
            _DataTable.Columns.Add("ENTMODE", typeof(string));
            _DataTable.Columns.Add("CNSTP", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("TAMOUNT", typeof(string));
            _DataTable.Columns.Add("SAMOUNT", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONID", typeof(string));
            _DataTable.Columns.Add("ROUTING", typeof(string));
            _DataTable.Columns.Add("ACTUALAMOUNT", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("COMPLAINTID", typeof(string));
            _DataTable.Columns.Add("CLAIMDATE", typeof(string));
            _DataTable.Columns.Add("CurrencyCode", typeof(string));
            int LineNo = 0;
            try
            {
                int _TotalRows = 0;

                string[] LogFile = File.ReadAllLines(path, Encoding.Default);
                TotalCount = LogFile.Length;

                _TotalRows = LogFile.Length;
                string year = string.Empty;
                DateTime FileDate1 = DateTime.ParseExact(LogFile[1].ToString().Substring(LogFile[1].Length - 8, 8), "dd/MM/yy", CultureInfo.InvariantCulture);
                //string FileDate = FileDate1.Day.ToString("dd") + "-" + FileDate1.ToString("MMM") + "-" + FileDate1.ToString("yy");// + FileDate1.ToString(" hh.mm.ss tt");

                year = "20" + LogFile[1].ToString().Substring(LogFile[1].Length - 2, 2);
                int StartIndex = -1;
                int EndIndex = -1;
                string CHANNELID = string.Empty;
                string MODEID = string.Empty;
                string CPDateStr = string.Empty;

                string _TotalRecordsRow = string.Empty;
                string _TR_TIMESTAMP = string.Empty;
                string _Cardnumber = string.Empty;
                string _referenceNumber = string.Empty;
                string _TraceNumber = string.Empty;
                string _TerminalOrIssuerId = string.Empty;
                string _TranType = string.Empty;
                string _ProcessingCode = string.Empty;
                string _EntMode = string.Empty;
                string _CNSTP = string.Empty;
                string _RespCode = string.Empty;
                string _TransactionAmount = string.Empty;
                string _SettelmentAmount = string.Empty;
                string _TERMINALID = string.Empty;
                string _TransactionID = string.Empty;
                string strAmount = string.Empty;
                string _Routing = string.Empty;
                string _FeeLevel = string.Empty;
                string _ActualAmmt = string.Empty;
                double mainamount;
                double stramnt;
                string _Stan = string.Empty;
                string _DrCrType = string.Empty;
                string COMPLAINTID = string.Empty;
                DateTime? TimeStamp1 = null;
                string Year = string.Empty;
                string Month = string.Empty;
                string Date = string.Empty;
                string ReserveField1 = string.Empty;
                string ReserveField2 = string.Empty;
                string Central_Processing_Date = string.Empty;
                int fyear = 0;
                int month = 0;
                string FileNameSplit = string.Empty;
                string FileDateString = string.Empty;

                string FileDateStr = string.Empty;
                string FName = Path.GetFileNameWithoutExtension(FileName);
                fyear = Convert.ToInt32(FName.Substring(FName.Length - 2, 2));

                string CurrencyCode = string.Empty;

                for (int j = 0; j < TotalCount; j++)
                {
                    StartIndex = GetIndex(LogFile, j, "Dispute Financial Status Advice");
                    EndIndex = GetIndex(LogFile, StartIndex, "Rate Table ID");

                    if (StartIndex == -1)
                    {
                        break;
                    }

                    if (StartIndex != -1 && EndIndex != -1)
                    {
                        _TotalRecordsRow = string.Empty;
                        _TR_TIMESTAMP = string.Empty;
                        _Cardnumber = string.Empty;
                        _referenceNumber = string.Empty;
                        _TraceNumber = string.Empty;
                        _TerminalOrIssuerId = string.Empty;
                        _TranType = string.Empty;
                        _ProcessingCode = string.Empty;
                        _EntMode = string.Empty;
                        _CNSTP = string.Empty;
                        _RespCode = string.Empty;
                        _TransactionAmount = string.Empty;
                        _SettelmentAmount = string.Empty;
                        _TERMINALID = string.Empty;
                        _TransactionID = string.Empty;
                        strAmount = string.Empty;
                        _Routing = string.Empty;
                        _FeeLevel = string.Empty;
                        _ActualAmmt = string.Empty;
                        _Stan = string.Empty;
                        _DrCrType = string.Empty;
                        COMPLAINTID = string.Empty;
                        TimeStamp1 = null;
                        Year = string.Empty;
                        Month = string.Empty;
                        Date = string.Empty;
                        ReserveField1 = string.Empty;
                        ReserveField2 = string.Empty;
                        Central_Processing_Date = string.Empty;

                        FName = Path.GetFileNameWithoutExtension(FileName);
                        fyear = Convert.ToInt32(FName.Substring(FName.Length - 2, 2));

                        CurrencyCode = string.Empty;

                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {
                                _TotalRecordsRow = LogFile[k];
                                if (_TotalRecordsRow.Contains("Purchase Date"))
                                {
                                    _TR_TIMESTAMP = _TotalRecordsRow.Substring(27, 8);
                                    Year = _TotalRecordsRow.Substring(27, 4);
                                    Month = _TR_TIMESTAMP.Substring(4, 2);
                                    Date = _TR_TIMESTAMP.Substring(6, 2).ToString();
                                    _TR_TIMESTAMP = Date + '-' + Month + "-" + Year;
                                    TimeStamp1 = DateTime.ParseExact(_TR_TIMESTAMP, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                                }

                                if (_TotalRecordsRow.Contains("Acct Number & Extension"))
                                {
                                    _Cardnumber = _TotalRecordsRow.Substring(27, 16);
                                }
                                if (_TotalRecordsRow.Contains("Source Amount"))
                                {
                                    mainamount = double.Parse(_TotalRecordsRow.Substring(27, 16));
                                    stramnt = mainamount / 100;
                                    _TransactionAmount = stramnt.ToString();
                                }
                                if (_TotalRecordsRow.Contains("Destination Amount"))
                                {
                                    _SettelmentAmount = _TotalRecordsRow.Substring(27, 16);
                                }

                                if (_TotalRecordsRow.Contains("Surcharge Credit/Dbt Ind"))
                                {
                                    _DrCrType = _TotalRecordsRow.Substring(93, 10).Trim();

                                }

                                if (_TotalRecordsRow.Contains("Source Currency Code"))
                                {
                                    int n;
                                    bool isNumeric = int.TryParse(_TotalRecordsRow.Substring(27, 16).ToString().Trim(), out n);
                                    if (isNumeric == true)
                                    {

                                        if (!_TotalRecordsRow.Substring(27, 16).ToString().Trim().Contains("50"))
                                        {
                                            CurrencyCode = "0";
                                        }

                                    }

                                }

                                if (_TotalRecordsRow.Contains("Acquirer Reference Nbr"))
                                {
                                    _referenceNumber = _TotalRecordsRow.Substring(27, 37).Trim();
                                    _Stan = _referenceNumber.Substring(_referenceNumber.Length - 6, 6);
                                    _TraceNumber = _referenceNumber.Substring(_referenceNumber.Length - 6, 6); ;
                                }
                                if (_TotalRecordsRow.Contains("Authorization Code"))
                                {

                                    _ProcessingCode = _TotalRecordsRow.Substring(93, 7);
                                }
                                if (_TotalRecordsRow.Contains("Terminal ID"))
                                {
                                    _TERMINALID = _TotalRecordsRow.Substring(27, 8).Trim();
                                }

                                if (_TotalRecordsRow.Contains("VROL Case Number"))
                                {
                                    _TransactionID = _TotalRecordsRow.Substring(93, 37).Trim();
                                }

                                if (_TotalRecordsRow.Contains("Chargeback Reason Code"))
                                {
                                    ReserveField1 = _TotalRecordsRow.Substring(93, 5).Trim().ToString();
                                }
                                if (_TotalRecordsRow.Contains("Dispute Condition"))
                                {
                                    ReserveField2 = _TotalRecordsRow.Substring(93, 5).Trim().ToString();
                                }
                                if (_TotalRecordsRow.Contains("Dispute Status"))
                                {
                                    _RespCode = _TotalRecordsRow.Substring(27, 10).Trim().ToString();
                                }
                                if (_TotalRecordsRow.Contains("Central Processing Date"))
                                {
                                    Central_Processing_Date = _TotalRecordsRow.Substring(93, 6).Trim();

                                    try
                                    {
                                        if (Convert.ToInt32(Central_Processing_Date.Substring(0, 2)) > month)
                                        {
                                            year = (fyear - 1).ToString();
                                        }
                                        else
                                        {
                                            year = fyear.ToString();//DateTime.Now.Year.ToString();
                                        }

                                        int CDate = Convert.ToInt32(Central_Processing_Date);
                                        int CDay = CDate % 1000;
                                        if (CDay == 366)
                                        {
                                            CDay = CDay - 1;
                                        }
                                        int Cyear = fyear;
                                        var CDateTime = new DateTime(Cyear, 1, 1);
                                        var Central_Processing_DateTime = CDateTime.AddDays(CDay - 1);

                                        CPDateStr = Central_Processing_DateTime.Day.ToString() + "-" + Central_Processing_DateTime.ToString("MMM") + "-" + Central_Processing_DateTime.ToString("yy") + Central_Processing_DateTime.ToString(" hh:mm:ss tt");
                                    }
                                    catch
                                    {

                                        CPDateStr = CreatedDate;
                                    }
                                }

                                if (_TotalRecordsRow.Contains("Acct Number & Extension"))
                                {
                                    _Cardnumber = _TotalRecordsRow.Substring(27, 16);
                                    try
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                        _Cardnumber = _Cardnumber.Substring(0, 6) + "XXXXXXXXXXXXXXX".Substring(1, _Cardnumber.Length - 10) + _Cardnumber.Substring(_Cardnumber.Length - 4, 4);
                                    }
                                    catch
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                j = EndIndex;
                            }
                        }
                        Random generator = new Random();
                        String strComplaintID = generator.Next(100000, 999999).ToString("D6");
                        COMPLAINTID = strComplaintID + _referenceNumber.Substring(_referenceNumber.Length - 4).ToString();
                        j = EndIndex;

                        _DataTable.Rows.Add(TimeStamp1.ToString(), _Cardnumber.Trim(), _referenceNumber.Trim(), _TraceNumber.Trim(), _TerminalOrIssuerId.Trim(), _TranType.Trim(), _ProcessingCode.Trim(), _EntMode.Trim(), _CNSTP.Trim(), _RespCode.Trim(), (_TransactionAmount.Replace(",", string.Empty)), _SettelmentAmount, _DrCrType, _TERMINALID.Trim(), _TransactionID.Trim(), _Routing.Trim(), _TransactionAmount, _Stan, FileName, path, FileDate1, CreatedDate, "", UserName, "", "", "", "", "", "", COMPLAINTID, CPDateStr, CurrencyCode);
                        LineNo++;
                    }
                }

                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    TotalCount = _DataTable.Rows.Count;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }
            return _DataTable;

        }

        public DataTable SplitDataREPRESENTMENT(string path, string FileName, DataTable dt, out int InsertCount, out int TotalCount, string UserName, string ClientCode)
        {
            MethodBase? currentMethod = MethodBase.GetCurrentMethod();
            DateTime CreatedDt = DateTime.Now;
            string CreatedDate = CreatedDt.Day.ToString() + "-" + CreatedDt.ToString("MMM") + "-" + CreatedDt.ToString("yy") + CreatedDt.ToString(" hh:mm:ss tt");

            InsertCount = 0;
            TotalCount = 0;
            DataTable _DataTable = new DataTable();
            _DataTable.Columns.Add("TR_TIMESTAMP", typeof(string));
            _DataTable.Columns.Add("CARDNO", typeof(string));
            _DataTable.Columns.Add("REFNO", typeof(string));
            _DataTable.Columns.Add("TRACENO", typeof(string));
            _DataTable.Columns.Add("TERMINALISSUERID", typeof(string));
            _DataTable.Columns.Add("TRANSTYPE", typeof(string));
            _DataTable.Columns.Add("PROCESSINGCODE", typeof(string));
            _DataTable.Columns.Add("ENTMODE", typeof(string));
            _DataTable.Columns.Add("CNSTP", typeof(string));
            _DataTable.Columns.Add("RESPONSECODE", typeof(string));
            _DataTable.Columns.Add("TAMOUNT", typeof(string));
            _DataTable.Columns.Add("SAMOUNT", typeof(string));
            _DataTable.Columns.Add("DrCrType", typeof(string));
            _DataTable.Columns.Add("TERMINALID", typeof(string));
            _DataTable.Columns.Add("TRANSACTIONID", typeof(string));
            _DataTable.Columns.Add("ROUTING", typeof(string));
            _DataTable.Columns.Add("ACTUALAMOUNT", typeof(string));
            _DataTable.Columns.Add("STAN", typeof(string));
            _DataTable.Columns.Add("FileName", typeof(string));
            _DataTable.Columns.Add("FilePath", typeof(string));
            _DataTable.Columns.Add("FileDate", typeof(string));
            _DataTable.Columns.Add("CreatedOn", typeof(string));
            _DataTable.Columns.Add("ModifiedOn", typeof(string));
            _DataTable.Columns.Add("CreatedBy", typeof(string));
            _DataTable.Columns.Add("ModifiedBy", typeof(string));
            _DataTable.Columns.Add("ReserveField1", typeof(string));
            _DataTable.Columns.Add("ReserveField2", typeof(string));
            _DataTable.Columns.Add("ReserveField3", typeof(string));
            _DataTable.Columns.Add("ReserveField4", typeof(string));
            _DataTable.Columns.Add("ReserveField5", typeof(string));
            _DataTable.Columns.Add("COMPLAINTID", typeof(string));
            _DataTable.Columns.Add("CLAIMDATE", typeof(string));
            int StartIndex = -1;
            int EndIndex = -1;
            int StartIndex1 = -1;
            int EndIndex1 = -1;
            int StartIndex2 = -1;
            int EndIndex2 = -1;
            int StartIndex3 = -1;
            int EndIndex3 = -1;
            int LineNo = 0;
            
            try
            {
                int _TotalRows = 0;

                string[] LogFile = File.ReadAllLines(path, Encoding.Default);
                TotalCount = LogFile.Length;
                string CPDateStr = string.Empty;
                _TotalRows = LogFile.Length;
                string year = string.Empty;
                DateTime FileDate1 = DateTime.ParseExact(LogFile[1].ToString().Substring(LogFile[1].Length - 8, 8), "dd/MM/yy", CultureInfo.InvariantCulture);
                
                year = "20" + LogFile[1].ToString().Substring(LogFile[1].Length - 2, 2);

                string CHANNELID = string.Empty;
                string MODEID = string.Empty;

                string _TotalRecordsRow = string.Empty;
                string _TR_TIMESTAMP = string.Empty;
                string _Cardnumber = string.Empty;
                string _referenceNumber = string.Empty;
                string _TraceNumber = string.Empty;
                string _TerminalOrIssuerId = string.Empty;
                string _TranType = string.Empty;
                string _ProcessingCode = string.Empty;
                string _EntMode = string.Empty;
                string _CNSTP = string.Empty;
                string _RespCode = string.Empty;
                string Central_Processing_Date = string.Empty;
                int fyear = 0;
                int month = 0;
                string _TransactionAmount = string.Empty;
                string _SettelmentAmount = string.Empty;
                string _TERMINALID = string.Empty;
                string _TransactionID = string.Empty;
                string strAmount = string.Empty;
                string _Routing = string.Empty;
                string _FeeLevel = string.Empty;
                string _ActualAmmt = string.Empty;
                double mainamount; 
                double stramnt;
                string _Stan = string.Empty;
                string _DrCrType = string.Empty;
                string COMPLAINTID = string.Empty;
                DateTime? TimeStamp1 = null;
                string Year = string.Empty;
                string Month = string.Empty;
                string Date = string.Empty;
                string ReserveField1 = string.Empty;
                string ReserveField2 = string.Empty;

                DateTime? ClaimDate = null;

                for (int j = 0; j < TotalCount; j++)
                { 

                    StartIndex = GetIndex(LogFile, j, "Cash Disbursement - Representment - VCR");
                    EndIndex = GetIndex(LogFile, StartIndex + 1, "CVV2 Result Code");


                    if (StartIndex == -1)
                    {

                        StartIndex1 = GetIndex(LogFile, j, "Dispute Financial Status Advice");
                        EndIndex1 = GetIndex(LogFile, StartIndex1, "Rate Table ID");
                    }
                    if (StartIndex1 == -1 && StartIndex == -1)
                    {
                        StartIndex2 = GetIndex(LogFile, j, "Sales Draft - Representment - VCR");
                        EndIndex2 = GetIndex(LogFile, StartIndex2, "CVV2 Result Code");
                    }

                    if ((StartIndex != -1 && EndIndex != -1) || (StartIndex1 != -1 && EndIndex1 != -1) || (StartIndex2 != -1 && EndIndex2 != -1) || (StartIndex3 != -1 && EndIndex3 != -1))
                    {
                        if (StartIndex1 > StartIndex2)
                        {
                            StartIndex = StartIndex1;
                            EndIndex = EndIndex1;
                        }
                        if (StartIndex2 > StartIndex1)
                        {
                            StartIndex = StartIndex2;
                            EndIndex = EndIndex2;
                        }
                        _TotalRecordsRow = string.Empty;
                        _TR_TIMESTAMP = string.Empty;
                        _Cardnumber = string.Empty;
                        _referenceNumber = string.Empty;
                        _TraceNumber = string.Empty;
                        _TerminalOrIssuerId = string.Empty;
                        _TranType = string.Empty;
                        _ProcessingCode = string.Empty;
                        _EntMode = string.Empty;
                        _CNSTP = string.Empty;
                        _RespCode = string.Empty;
                        Central_Processing_Date = string.Empty;
                        fyear = 0;
                        month = 0;
                        _TransactionAmount = string.Empty;
                        _SettelmentAmount = string.Empty;
                        _TERMINALID = string.Empty;
                        _TransactionID = string.Empty;
                        strAmount = string.Empty;
                        _Routing = string.Empty;
                        _FeeLevel = string.Empty;
                        _ActualAmmt = string.Empty; 
                        _Stan = string.Empty;
                        _DrCrType = string.Empty;
                        COMPLAINTID = string.Empty;
                        TimeStamp1 = null;
                        Year = string.Empty;
                        Month = string.Empty;
                        Date = string.Empty;
                        ReserveField1 = string.Empty;
                        ReserveField2 = string.Empty;

                        ClaimDate = null;

                        for (int k = StartIndex; k <= EndIndex; k++)
                        {
                            try
                            {

                                _TotalRecordsRow = LogFile[k];
                                if (_TotalRecordsRow.Contains("Purchase Date"))
                                {
                                    _TR_TIMESTAMP = _TotalRecordsRow.Substring(27, 8);
                                    Year = _TotalRecordsRow.Substring(27, 4);
                                    Month = _TR_TIMESTAMP.Substring(4, 2);
                                    Date = _TR_TIMESTAMP.Substring(6, 2).ToString();
                                    _TR_TIMESTAMP = Date + '-' + Month + "-" + Year;
                                    TimeStamp1 = DateTime.ParseExact(_TR_TIMESTAMP, "dd-MM-yyyy", CultureInfo.InvariantCulture);
                                }

                                if (_TotalRecordsRow.Contains("Acct Number & Extension"))
                                {
                                    _Cardnumber = _TotalRecordsRow.Substring(27, 16);
                                }
                                if (_TotalRecordsRow.Contains("Source Amount"))
                                {
                                    mainamount = double.Parse(_TotalRecordsRow.Substring(27, 16));
                                    stramnt = mainamount / 100; 
                                    _TransactionAmount = stramnt.ToString(); 
                                }
                                if (_TotalRecordsRow.Contains("Destination Amount"))
                                {
                                    _SettelmentAmount = _TotalRecordsRow.Substring(27, 16);
                                }

                                if (_TotalRecordsRow.Contains("Surcharge Credit/Dbt Ind"))
                                {
                                    _DrCrType = _TotalRecordsRow.Substring(93, 10).Trim();

                                } 

                                if (_TotalRecordsRow.Contains("Acquirer Reference Nbr"))
                                {
                                    _referenceNumber = _TotalRecordsRow.Substring(27, 37).Trim();
                                    _Stan = _referenceNumber.Substring(_referenceNumber.Length - 7, 7);
                                    _TraceNumber = _referenceNumber.Substring(_referenceNumber.Length - 7, 7); ;
                                }
                                if (_TotalRecordsRow.Contains("Authorization Code"))
                                {

                                    _ProcessingCode = _TotalRecordsRow.Substring(93, 7);
                                }
                                if (_TotalRecordsRow.Contains("Terminal ID"))
                                {
                                    _TERMINALID = _TotalRecordsRow.Substring(27, 8).Trim();
                                }
                              
                                if (_TotalRecordsRow.Contains("VROL Case Number"))
                                {
                                    _TransactionID = _TotalRecordsRow.Substring(93, 37).Trim();
                                } 

                                if (_TotalRecordsRow.Contains("Chargeback Reason Code"))
                                {
                                    ReserveField1 = _TotalRecordsRow.Substring(93, 5).Trim().ToString();
                                }
                                if (_TotalRecordsRow.Contains("Dispute Condition"))
                                {
                                    ReserveField2 = _TotalRecordsRow.Substring(93, 5).Trim().ToString();
                                }
                                if (_TotalRecordsRow.Contains("Dispute Status"))
                                {
                                    _RespCode = _TotalRecordsRow.Substring(93, 10).Trim().ToString() != "P1" ? _TotalRecordsRow.Substring(27, 10).Trim().ToString() : _TotalRecordsRow.Substring(93, 10).Trim().ToString();
                                }
                             
                                if (_TotalRecordsRow.Contains("Central Processing Date"))
                                {
                                    try
                                    {
                                        if (FileName.Contains("EP707"))
                                        {
                                            ClaimDate = DateTime.ParseExact(_TotalRecordsRow.Substring(93, 10).Trim().ToString(), "yyyyMMdd", CultureInfo.InvariantCulture);
                                        }
                                        else
                                        {

                                            Central_Processing_Date = _TotalRecordsRow.Substring(93, 6).Trim();
                                            
                                            try
                                            {
                                                if (Convert.ToInt32(Central_Processing_Date.Substring(0, 2)) > month)
                                                {
                                                    year = (fyear - 1).ToString();
                                                }
                                                else
                                                {
                                                    year = fyear.ToString();//DateTime.Now.Year.ToString();
                                                }

                                                int CDate = Convert.ToInt32(Central_Processing_Date);
                                                int CDay = CDate % 1000;
                                                if (CDay == 366)
                                                {
                                                    CDay = CDay - 1;
                                                }
                                                int Cyear = fyear;
                                                var CDateTime = new DateTime(Cyear, 1, 1);
                                                var Central_Processing_DateTime = CDateTime.AddDays(CDay - 1);
                                                
                                                CPDateStr = Central_Processing_DateTime.Day.ToString() + "-" + Central_Processing_DateTime.ToString("MMM") + "-" + Central_Processing_DateTime.ToString("yy") + Central_Processing_DateTime.ToString(" hh:mm:ss tt");
                                            }
                                            catch
                                            {
                                                CPDateStr = CreatedDate;
                                            }
                                        }

                                    }

                                    catch
                                    {
                                        ClaimDate = CreatedDt;
                                    }
                                } 

                                if (_TotalRecordsRow.Contains("Acct Number & Extension"))
                                {

                                    string dummy = "XXXXXXXXXXXXXXX";
                                    _Cardnumber = _TotalRecordsRow.Substring(27, 16);
                                    try
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                        _Cardnumber = _Cardnumber.Substring(0, 6) + dummy.Substring(1, _Cardnumber.Length - 10) + _Cardnumber.Substring(_Cardnumber.Length - 4, 4);
                                    }
                                    catch
                                    {
                                        _Cardnumber = _Cardnumber.ToString().Trim();
                                    }
                                }
                            }
                            catch (Exception ex)
                            {
                                j = EndIndex; 
                            }
                        }
                        Random generator = new Random();
                        String strComplaintID = generator.Next(100000, 999999).ToString("D6");
                        COMPLAINTID = strComplaintID + _referenceNumber.Substring(_referenceNumber.Length - 4).ToString();
                        j = EndIndex;

                        _DataTable.Rows.Add(TimeStamp1.ToString(), _Cardnumber.Trim(), _referenceNumber.Trim(), _TraceNumber.Trim(), _TerminalOrIssuerId.Trim(), _TranType.Trim(), _ProcessingCode.Trim(), _EntMode.Trim(), _CNSTP.Trim(), _RespCode.Trim(), (_TransactionAmount.Replace(",", string.Empty)), _SettelmentAmount, _DrCrType, _TERMINALID.Trim(), _TransactionID.Trim(), _Routing.Trim(), _TransactionAmount, _Stan, FileName, path, FileDate1, CreatedDate, "", UserName, "", "", "", "", "", "", COMPLAINTID, CPDateStr);
                        LineNo++;
                    }
                }

                if (_DataTable.Rows.Count > 0)
                {
                    InsertCount = _DataTable.Rows.Count;
                    TotalCount = _DataTable.Rows.Count;
                }

            }

            catch (Exception ex)
            {
                DBLog.InsertLogs(ex.Message.ToString(), ClientCode, bulkimports.GetLocalIPAddress(), currentMethod?.DeclaringType?.Name, currentMethod?.Name, LineNo, FileName, UserName, 'E', _connectionString);
            }

            return _DataTable;

        }
    }
}
 